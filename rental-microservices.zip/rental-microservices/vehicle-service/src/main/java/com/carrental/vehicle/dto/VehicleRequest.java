package com.carrental.vehicle.dto;

import com.carrental.vehicle.model.VehicleStatus;
import com.carrental.vehicle.model.VehicleType;

public record VehicleRequest(
        String vehicleNumber,
        String companyName,
        String modelName,
        VehicleType vehicleType,
        VehicleStatus status,
        double dailyRentalCost,
        double hourlyRentalCost,
        String location,
        Double latitude,
        Double longitude
) {
}
