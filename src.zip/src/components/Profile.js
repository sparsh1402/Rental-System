import { useState, useEffect, useContext } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";
import { useToast } from "../context/ToastContext";
import { apiJson } from "../api/client";
import Footer from "./Footer";

const Profile = () => {
    const {isLogged,user,logout} = useContext(AuthContext);
    const [newPassword, setNewPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [error, setError] = useState(null);
    const [details, setDetails] = useState(user);
    const userId = localStorage.getItem("userId");
    const { token } = useContext(AuthContext);
    const { showToast } = useToast();
    
    useEffect(() => {
      const fetchUserData = async () => {
        if (!userId) return;
        try {
          const data = await apiJson(`/api/users/${userId}`);
          setDetails(data);
        } catch (err) {
          setError("Failed to load user data. Please try again later.");
        }
      };
      fetchUserData();
    }, [userId, token]);
  
    const handleUpdate = async () => {
      if (newPassword !== confirmPassword) {
        setError("Passwords do not match!");
        return;
      }
      try {
        await apiJson("/api/users/update-password", {
          method: "POST",
          body: JSON.stringify({
            email: user.email,
            newPassword,
            confirmPassword,
          }),
        });
        showToast("Password updated successfully!", "success");
        setNewPassword("");
        setConfirmPassword("");
      } catch (err) {
        setError("Failed to update profile.");
      }
    };
  
    return (
      <div className="bg-white shadow p-6 rounded-lg flex-1">
        <h3 className="text-xl font-bold mb-4">My Profile</h3>
        {error && <p className="text-red-500">{error}</p>}
        <div className="mb-4 text-sm text-gray-600">
          <p><span className="font-semibold">Name:</span> {details?.name}</p>
          <p><span className="font-semibold">Email:</span> {details?.email}</p>
          <p><span className="font-semibold">Role:</span> {details?.role}</p>
        </div>
        <h4 className="font-semibold mb-2">Change Password</h4>
        <div className="grid grid-cols-2 gap-4">
          <input
            type="text"
            placeholder="Username"
            value={details?.name || ""}
            readOnly
            className="border p-2 w-full bg-gray-100"
          />
          <input
            type="email"
            placeholder="Email"
            value={details?.email || ""}
            readOnly
            className="border p-2 w-full bg-gray-100"
          />
          <input
            type="password"
            placeholder="New Password"
            value={newPassword}
            onChange={(e) => setNewPassword(e.target.value)}
            className="border p-2 w-full"
          />
          <input
            type="password"
            placeholder="Re-Enter Password"
            value={confirmPassword}
            onChange={(e) => setConfirmPassword(e.target.value)}
            className="border p-2 w-full"
          />
        </div>
        <button className="mt-4 bg-black text-white py-2 px-6 rounded" onClick={handleUpdate}>
          Update Password
        </button>
      </div>
    );
  };
  
export default Profile;
