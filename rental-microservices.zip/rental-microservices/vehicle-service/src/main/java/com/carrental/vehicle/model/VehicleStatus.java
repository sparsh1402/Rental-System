package com.carrental.vehicle.model;

public enum VehicleStatus {
    AVAILABLE, RENTED
}
