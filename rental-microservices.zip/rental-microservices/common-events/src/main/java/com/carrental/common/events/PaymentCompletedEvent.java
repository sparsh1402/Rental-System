package com.carrental.common.events;

import java.time.Instant;

/**
 * Emitted by payment-service when a payment succeeds. Consumed by
 * reservation-service (confirm booking) and notification-service.
 */
public record PaymentCompletedEvent(
        Long reservationId,
        Long paymentId,
        Long vehicleId,
        double amount,
        Instant occurredAt
) {
}
