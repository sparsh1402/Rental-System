package com.carrental.reservation.service;

import com.carrental.reservation.model.PaymentStatus;
import com.carrental.reservation.model.Reservation;
import com.carrental.reservation.model.ReservationStatus;
import com.carrental.reservation.repository.ReservationRepository;
import com.carrental.reservation.repository.VehicleLockRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.NoSuchElementException;
import java.util.Optional;

/**
 * All database mutations that must be transactional live here so Spring's proxy
 * actually applies @Transactional (avoids self-invocation pitfalls). State
 * transitions are idempotent to tolerate duplicate Kafka deliveries.
 */
@Service
public class BookingTransactionService {

    private final ReservationRepository reservationRepository;
    private final VehicleLockRepository vehicleLockRepository;

    public BookingTransactionService(ReservationRepository reservationRepository,
                                     VehicleLockRepository vehicleLockRepository) {
        this.reservationRepository = reservationRepository;
        this.vehicleLockRepository = vehicleLockRepository;
    }

    /**
     * Serializes per-vehicle via a pessimistic row lock, rejects overlapping
     * bookings, then persists the reservation. The lock row must already exist
     * (created by VehicleLockService in its own transaction).
     */
    @Transactional
    public Reservation lockAndSave(Long userId, Long vehicleId,
                                   LocalDateTime start, LocalDateTime end, double cost) {
        vehicleLockRepository.findByIdForUpdate(vehicleId)
                .orElseThrow(() -> new IllegalStateException("Vehicle lock missing for " + vehicleId));

        if (reservationRepository.countOverlapping(vehicleId, start, end) > 0) {
            throw new IllegalStateException("Vehicle is not available for the selected dates");
        }

        Reservation reservation = new Reservation();
        reservation.setUserId(userId);
        reservation.setVehicleId(vehicleId);
        reservation.setStartDate(start);
        reservation.setEndDate(end);
        reservation.setTotalCost(cost);
        reservation.setStatus(ReservationStatus.SCHEDULED);
        reservation.setPaymentStatus(PaymentStatus.PENDING);
        return reservationRepository.save(reservation);
    }

    @Transactional
    public Optional<Reservation> markConfirmed(Long reservationId) {
        Reservation reservation = find(reservationId);
        if (reservation.getStatus() == ReservationStatus.COMPLETED
                || reservation.getStatus() == ReservationStatus.CANCELLED) {
            return Optional.empty();
        }
        reservation.setStatus(ReservationStatus.COMPLETED);
        reservation.setPaymentStatus(PaymentStatus.PAID);
        return Optional.of(reservationRepository.save(reservation));
    }

    @Transactional
    public Optional<Reservation> markCancelled(Long reservationId, boolean paymentFailed) {
        Reservation reservation = find(reservationId);
        if (reservation.getStatus() == ReservationStatus.CANCELLED) {
            return Optional.empty();
        }
        reservation.setStatus(ReservationStatus.CANCELLED);
        if (paymentFailed) {
            reservation.setPaymentStatus(PaymentStatus.FAILED);
        }
        return Optional.of(reservationRepository.save(reservation));
    }

    private Reservation find(Long reservationId) {
        return reservationRepository.findById(reservationId)
                .orElseThrow(() -> new NoSuchElementException("Reservation not found: " + reservationId));
    }
}
