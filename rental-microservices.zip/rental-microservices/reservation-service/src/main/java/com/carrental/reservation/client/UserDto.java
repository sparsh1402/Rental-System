package com.carrental.reservation.client;

public record UserDto(Long id, String name, String email, String role) {
}
