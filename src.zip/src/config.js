// Single source of truth for the backend base URL. In the microservices setup
// every request goes through the API gateway (default http://localhost:8080).
// Override at build time with REACT_APP_API_URL.
export const API_BASE_URL =
  process.env.REACT_APP_API_URL || "http://localhost:8080";
