package com.carrental.common.events;

import java.time.Instant;

/**
 * Emitted by reservation-service when a booking is created (status SCHEDULED,
 * payment PENDING). Consumed by payment-service, vehicle-service and
 * notification-service. Keyed by vehicleId on the topic so events for the same
 * vehicle stay ordered within a partition.
 */
public record ReservationCreatedEvent(
        Long reservationId,
        Long userId,
        Long vehicleId,
        double totalCost,
        String startDate,
        String endDate,
        Instant occurredAt
) {
}
