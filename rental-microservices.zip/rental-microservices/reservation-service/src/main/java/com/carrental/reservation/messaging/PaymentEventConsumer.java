package com.carrental.reservation.messaging;

import com.carrental.common.events.KafkaTopics;
import com.carrental.common.events.PaymentCompletedEvent;
import com.carrental.common.events.PaymentFailedEvent;
import com.carrental.reservation.service.ReservationService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Continues the saga based on the payment outcome: confirm the booking on
 * success, or run the compensating cancellation on failure.
 */
@Component
@KafkaListener(topics = KafkaTopics.PAYMENT_EVENTS, groupId = "reservation-service")
public class PaymentEventConsumer {

    private static final Logger log = LoggerFactory.getLogger(PaymentEventConsumer.class);

    private final ReservationService reservationService;

    public PaymentEventConsumer(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @KafkaHandler
    public void onCompleted(PaymentCompletedEvent event) {
        log.info("Payment completed for reservation {} -> confirming", event.reservationId());
        reservationService.onPaymentCompleted(event.reservationId());
    }

    @KafkaHandler
    public void onFailed(PaymentFailedEvent event) {
        log.info("Payment failed for reservation {} -> compensating", event.reservationId());
        reservationService.onPaymentFailed(event.reservationId(), event.reason());
    }

    @KafkaHandler(isDefault = true)
    public void onOther(Object event) {
        log.debug("Ignoring payment event type {}", event.getClass().getSimpleName());
    }
}
