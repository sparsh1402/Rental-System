package com.carrental.reservation.messaging;

import com.carrental.common.events.KafkaTopics;
import com.carrental.common.events.ReservationCancelledEvent;
import com.carrental.common.events.ReservationConfirmedEvent;
import com.carrental.common.events.ReservationCreatedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/**
 * Publishes reservation lifecycle events. Messages are keyed by vehicleId so all
 * events for a given vehicle land in the same partition and stay ordered.
 */
@Component
public class ReservationEventPublisher {

    private static final Logger log = LoggerFactory.getLogger(ReservationEventPublisher.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public ReservationEventPublisher(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishCreated(ReservationCreatedEvent event) {
        log.info("Publishing ReservationCreated for reservation {}", event.reservationId());
        kafkaTemplate.send(KafkaTopics.RESERVATION_EVENTS, key(event.vehicleId()), event);
    }

    public void publishConfirmed(ReservationConfirmedEvent event) {
        log.info("Publishing ReservationConfirmed for reservation {}", event.reservationId());
        kafkaTemplate.send(KafkaTopics.RESERVATION_EVENTS, key(event.vehicleId()), event);
    }

    public void publishCancelled(ReservationCancelledEvent event) {
        log.info("Publishing ReservationCancelled for reservation {}", event.reservationId());
        kafkaTemplate.send(KafkaTopics.RESERVATION_EVENTS, key(event.vehicleId()), event);
    }

    private String key(Long vehicleId) {
        return String.valueOf(vehicleId);
    }
}
