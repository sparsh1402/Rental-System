package com.carrental.payment.model;

public enum PaymentRecordStatus {
    PENDING, PAID, FAILED
}
