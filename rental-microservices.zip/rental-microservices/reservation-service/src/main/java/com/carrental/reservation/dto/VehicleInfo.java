package com.carrental.reservation.dto;

/** Vehicle fields embedded in a reservation response for the UI. */
public record VehicleInfo(String companyName, String modelName, String imageUrl, String location) {
}
