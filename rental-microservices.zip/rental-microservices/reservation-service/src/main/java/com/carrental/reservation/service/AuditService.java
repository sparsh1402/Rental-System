package com.carrental.reservation.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * Fire-and-forget side effects. Annotating with @Async offloads the work to the
 * "taskExecutor" thread pool so it never slows down the booking request thread.
 */
@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    @Async("taskExecutor")
    public void recordBooking(Long reservationId, Long userId, Long vehicleId) {
        log.info("[audit/{}] reservation {} created by user {} for vehicle {}",
                Thread.currentThread().getName(), reservationId, userId, vehicleId);
    }
}
