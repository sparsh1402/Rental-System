package com.carrental.common.events;

import java.time.Instant;

/**
 * Emitted by reservation-service when a booking is cancelled (either by the user
 * or as a saga compensation after payment failure). Consumed by vehicle-service
 * to release the vehicle and by notification-service.
 */
public record ReservationCancelledEvent(
        Long reservationId,
        Long vehicleId,
        String reason,
        Instant occurredAt
) {
}
