package com.carrental.common.events;

import java.time.Instant;

/**
 * Emitted by payment-service when a payment fails. Triggers the compensating
 * action in reservation-service (cancel booking, release vehicle).
 */
public record PaymentFailedEvent(
        Long reservationId,
        Long vehicleId,
        String reason,
        Instant occurredAt
) {
}
