import { useEffect, useState } from "react";
import { Link } from "react-router-dom";

/* ------------------------------------------------------------------ */
/* Small presentational helpers                                        */
/* ------------------------------------------------------------------ */

const methodColors = {
  GET: "bg-emerald-100 text-emerald-700 border-emerald-300",
  POST: "bg-blue-100 text-blue-700 border-blue-300",
  PUT: "bg-amber-100 text-amber-700 border-amber-300",
  DELETE: "bg-red-100 text-red-700 border-red-300",
};

const Method = ({ m }) => (
  <span className={`inline-block text-xs font-bold px-2 py-0.5 rounded border ${methodColors[m] || "bg-gray-100 text-gray-700 border-gray-300"}`}>
    {m}
  </span>
);

const Pill = ({ children, color = "slate" }) => (
  <span className={`inline-block text-xs font-semibold px-2 py-0.5 rounded-full bg-${color}-100 text-${color}-700`}>
    {children}
  </span>
);

const Card = ({ title, children, accent = "indigo" }) => (
  <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
    {title && (
      <div className={`px-5 py-3 border-b border-gray-100 bg-${accent}-50`}>
        <h4 className="font-semibold text-gray-800">{title}</h4>
      </div>
    )}
    <div className="p-5">{children}</div>
  </div>
);

const Box = ({ children, color = "indigo" }) => (
  <div className={`rounded-lg border-2 border-${color}-300 bg-${color}-50 text-${color}-800 px-4 py-3 text-sm font-medium text-center shadow-sm min-w-[120px]`}>
    {children}
  </div>
);

const Arrow = ({ label, down }) => (
  <div className={`flex ${down ? "flex-col" : "items-center"} justify-center text-gray-400`}>
    {label && <span className="text-[11px] text-gray-500 px-2 whitespace-nowrap">{label}</span>}
    <span className="text-xl leading-none">{down ? "↓" : "→"}</span>
  </div>
);

const Section = ({ id, title, kicker, children }) => (
  <section id={id} className="scroll-mt-24 mb-16">
    {kicker && <p className="text-xs font-bold uppercase tracking-widest text-indigo-500 mb-1">{kicker}</p>}
    <h2 className="text-3xl font-bold text-gray-900 mb-6 border-b border-gray-200 pb-3">{title}</h2>
    {children}
  </section>
);

/* ------------------------------------------------------------------ */
/* Navigation config                                                   */
/* ------------------------------------------------------------------ */

const NAV = [
  { id: "overview", label: "Overview" },
  { id: "architecture", label: "Architecture" },
  { id: "microservices", label: "Microservices" },
  { id: "stack", label: "Tech Stack" },
  { id: "structure", label: "Project Structure" },
  { id: "data", label: "Data Model" },
  { id: "api", label: "API Reference" },
  { id: "flows", label: "Key Flows" },
  { id: "security", label: "Security" },
  { id: "setup", label: "Setup & Run" },
  { id: "issues", label: "Known Issues" },
];

/* ------------------------------------------------------------------ */
/* Page                                                                */
/* ------------------------------------------------------------------ */

const DocsPage = () => {
  const [active, setActive] = useState("overview");

  useEffect(() => {
    const handler = () => {
      let current = NAV[0].id;
      for (const item of NAV) {
        const el = document.getElementById(item.id);
        if (el && el.getBoundingClientRect().top <= 120) current = item.id;
      }
      setActive(current);
    };
    window.addEventListener("scroll", handler, { passive: true });
    handler();
    return () => window.removeEventListener("scroll", handler);
  }, []);

  return (
    <div className="min-h-screen bg-gray-50 text-gray-800" style={{ scrollBehavior: "smooth" }}>
      {/* Top bar */}
      <header className="sticky top-0 z-30 bg-gray-900 text-white shadow-md">
        <div className="max-w-7xl mx-auto px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <span className="text-2xl">🚗</span>
            <div>
              <h1 className="text-lg font-bold leading-tight">Drivee — Project Documentation</h1>
              <p className="text-xs text-gray-400 leading-tight">Car &amp; Bike Rental System · HLD + LLD · Flow Guide</p>
            </div>
          </div>
          <Link to="/" className="text-sm bg-white/10 hover:bg-white/20 px-4 py-2 rounded transition">
            ← Back to App
          </Link>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-6 flex gap-8">
        {/* Sidebar */}
        <aside className="hidden lg:block w-56 flex-shrink-0">
          <nav className="sticky top-20 py-8">
            <p className="text-xs font-bold uppercase tracking-widest text-gray-400 mb-3">On this page</p>
            <ul className="space-y-1">
              {NAV.map((item) => (
                <li key={item.id}>
                  <a
                    href={`#${item.id}`}
                    className={`block px-3 py-1.5 rounded text-sm transition ${
                      active === item.id
                        ? "bg-indigo-600 text-white font-semibold"
                        : "text-gray-600 hover:bg-gray-200"
                    }`}
                  >
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>
          </nav>
        </aside>

        {/* Main content */}
        <main className="flex-1 min-w-0 py-10">
          {/* Hero */}
          <div className="mb-14 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-2xl p-8 text-white shadow-lg">
            <h1 className="text-4xl font-extrabold mb-3">Understand the whole system in one page</h1>
            <p className="text-indigo-100 max-w-2xl">
              This page walks through the Car &amp; Bike Rental System end to end — its architecture, data model,
              REST API, and the exact flows that happen when a user signs in, books a vehicle, and pays.
            </p>
            <div className="flex flex-wrap gap-2 mt-5">
              {["React 18 SPA", "Spring Boot 3.1.4", "MySQL", "JWT Auth", "REST + JSON"].map((t) => (
                <span key={t} className="inline-block text-xs font-semibold px-2 py-0.5 rounded-full bg-white/20 text-white">
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* OVERVIEW */}
          <Section id="overview" kicker="Introduction" title="Overview">
            <p className="mb-4 leading-relaxed">
              <strong>Drivee</strong> is a car &amp; bike rental platform. Customers register, browse available
              vehicles, book one for a date/time range (cost auto-calculated), pay through a payment flow, and
              track their bookings in a personal dashboard. The system is split into two deployable parts:
            </p>
            <div className="grid md:grid-cols-2 gap-4">
              <Card title="Frontend — car-rental-frontend" accent="blue">
                <ul className="text-sm space-y-1 list-disc list-inside text-gray-600">
                  <li>React 18 Single-Page App (Create React App)</li>
                  <li>react-router-dom v7 for routing</li>
                  <li>Tailwind CSS styling</li>
                  <li>Auth state in <code>AuthContext</code> + localStorage</li>
                  <li>Runs on <code>localhost:3000</code></li>
                </ul>
              </Card>
              <Card title="Backend — car-rental-system" accent="emerald">
                <ul className="text-sm space-y-1 list-disc list-inside text-gray-600">
                  <li>Spring Boot 3.1.4 (Java 17)</li>
                  <li>Layered: Controller → Service → Repository → Entity</li>
                  <li>Spring Security + JWT (stateless)</li>
                  <li>Spring Data JPA / Hibernate → MySQL</li>
                  <li>Runs on <code>localhost:8080</code></li>
                </ul>
              </Card>
            </div>
            <div className="mt-4 bg-amber-50 border border-amber-200 rounded-lg p-4 text-sm text-amber-800">
              <strong>Note:</strong> This is a demo / learning-grade codebase. Razorpay and Kafka are scaffolded
              but currently disabled, and there are a few known issues listed at the bottom of this page.
            </div>
          </Section>

          {/* ARCHITECTURE */}
          <Section id="architecture" kicker="Big picture" title="System Architecture">
            <p className="mb-6 leading-relaxed">
              A classic 3-tier client–server design. The React SPA talks to the Spring Boot REST API over JSON,
              authenticated with a JWT bearer token. The API persists to MySQL and stores vehicle images on the
              local filesystem.
            </p>

            <Card>
              <div className="flex flex-col items-center gap-3">
                <Box color="blue">🌐 Browser / React SPA<br /><span className="text-xs font-normal">localhost:3000</span></Box>
                <Arrow down label="REST + JSON · Bearer JWT" />
                <Box color="emerald">⚙️ Spring Boot REST API<br /><span className="text-xs font-normal">localhost:8080</span></Box>
                <Arrow down />
                <div className="flex flex-wrap gap-4 justify-center">
                  <Box color="purple">🗄️ MySQL<br /><span className="text-xs font-normal">car_rental DB</span></Box>
                  <Box color="amber">🖼️ Local FS<br /><span className="text-xs font-normal">uploads/vehicle-images</span></Box>
                  <Box color="gray">💳 Razorpay<br /><span className="text-xs font-normal">(scaffolded)</span></Box>
                  <Box color="gray">📨 Kafka<br /><span className="text-xs font-normal">(disabled)</span></Box>
                </div>
              </div>
            </Card>

            <h3 className="text-xl font-semibold mt-8 mb-4">Backend layers</h3>
            <div className="space-y-2">
              {[
                ["Web / API Layer", "Controllers, CORS, JWT filter", "indigo"],
                ["Security Layer", "SecurityConfig, JwtRequestFilter, JwtUtil, CustomUserDetailsService", "rose"],
                ["Service / Business Layer", "UserService, VehicleService, ReservationService, PaymentService", "blue"],
                ["Data Access Layer", "UserRepository, VehicleRepository, ReservationRepository", "emerald"],
                ["Domain / Persistence", "JPA entities (User, Vehicle, Reservation) + enums", "amber"],
              ].map(([t, d, c]) => (
                <div key={t} className={`rounded-lg border-l-4 border-${c}-400 bg-white shadow-sm px-4 py-3`}>
                  <span className="font-semibold text-gray-800">{t}</span>
                  <span className="text-sm text-gray-500"> — {d}</span>
                </div>
              ))}
            </div>
          </Section>

          {/* MICROSERVICES */}
          <Section id="microservices" kicker="Evolution" title="Microservices Architecture">
            <p className="mb-6 leading-relaxed">
              The monolith above is being rebuilt into an event-driven microservices system
              (in <code className="bg-gray-100 px-1 rounded">rental-microservices/</code>) to learn
              microservices, Kafka, multithreading, and free-tier AWS deployment. A Spring Cloud
              Gateway validates the JWT at the edge and routes to five services; state changes flow
              asynchronously over Kafka as a choreography saga.
            </p>

            <Card>
              <div className="flex flex-col items-center gap-3">
                <Box color="blue">🌐 React SPA</Box>
                <Arrow down label="REST + JSON · Bearer JWT" />
                <Box color="indigo">🚪 api-gateway<br /><span className="text-xs font-normal">:8080 · JWT validation</span></Box>
                <Arrow down />
                <div className="flex flex-wrap gap-3 justify-center">
                  <Box color="emerald">🔐 auth-user<br /><span className="text-xs font-normal">:8081</span></Box>
                  <Box color="emerald">🚗 vehicle<br /><span className="text-xs font-normal">:8082</span></Box>
                  <Box color="emerald">📅 reservation<br /><span className="text-xs font-normal">:8083</span></Box>
                  <Box color="emerald">💳 payment<br /><span className="text-xs font-normal">:8084</span></Box>
                  <Box color="emerald">🔔 notification<br /><span className="text-xs font-normal">:8086</span></Box>
                </div>
                <Arrow down label="publish / consume events" />
                <div className="flex flex-wrap gap-3 justify-center">
                  <Box color="amber">📨 Kafka (KRaft)<br /><span className="text-xs font-normal">reservation-events · payment-events</span></Box>
                  <Box color="purple">🗄️ Postgres<br /><span className="text-xs font-normal">db per service</span></Box>
                </div>
              </div>
            </Card>

            <h3 className="text-xl font-semibold mt-8 mb-4">Booking saga (choreography)</h3>
            <Card>
              <ol className="list-decimal list-inside space-y-2 text-sm leading-relaxed">
                <li><strong>reservation-service</strong> takes a per-vehicle pessimistic lock, rejects overlaps, saves the booking (SCHEDULED/PENDING) and publishes <Pill color="amber">reservation.created</Pill>.</li>
                <li><strong>payment-service</strong> consumes it and initializes a PENDING payment; <strong>vehicle-service</strong> marks the vehicle RENTED.</li>
                <li>User confirms → payment-service publishes <Pill color="emerald">payment.completed</Pill> or <Pill color="red">payment.failed</Pill>.</li>
                <li><strong>reservation-service</strong> confirms the booking, or compensates by cancelling it (publishing <Pill color="rose">reservation.cancelled</Pill>, which frees the vehicle).</li>
                <li><strong>notification-service</strong> consumes every event and notifies the user.</li>
              </ol>
            </Card>

            <h3 className="text-xl font-semibold mt-8 mb-4">Concepts demonstrated</h3>
            <div className="grid md:grid-cols-2 gap-4">
              <Card title="Multithreading" accent="blue">
                <ul className="list-disc list-inside text-sm space-y-1">
                  <li>Per-vehicle pessimistic lock prevents double-booking (proven by a 16-thread <code className="bg-gray-100 px-1 rounded">ExecutorService</code> test — exactly one wins)</li>
                  <li><code className="bg-gray-100 px-1 rounded">CompletableFuture</code> parallel user + vehicle aggregation</li>
                  <li><code className="bg-gray-100 px-1 rounded">@Async</code> audit side-effect, <code className="bg-gray-100 px-1 rounded">@Scheduled</code> expiry job</li>
                </ul>
              </Card>
              <Card title="Kafka" accent="amber">
                <ul className="list-disc list-inside text-sm space-y-1">
                  <li>Producers/consumers, consumer groups, partition-by-vehicleId ordering</li>
                  <li>Class-level <code className="bg-gray-100 px-1 rounded">@KafkaHandler</code> type routing</li>
                  <li>Retries + dead-letter topics (<code className="bg-gray-100 px-1 rounded">*.DLT</code>), idempotent consumers</li>
                </ul>
              </Card>
              <Card title="Microservices" accent="indigo">
                <ul className="list-disc list-inside text-sm space-y-1">
                  <li>Edge JWT validation + header injection at the gateway</li>
                  <li>Database-per-service, independent deployability</li>
                  <li>Sync REST for queries, async events for state changes</li>
                </ul>
              </Card>
              <Card title="AWS free tier" accent="emerald">
                <ul className="list-disc list-inside text-sm space-y-1">
                  <li>Single t3.micro EC2 + Docker Compose + swap file</li>
                  <li>Lean JVM heaps, Kafka in KRaft mode (no ZooKeeper)</li>
                  <li>nginx serves the SPA and reverse-proxies the gateway</li>
                </ul>
              </Card>
            </div>
          </Section>

          {/* STACK */}
          <Section id="stack" kicker="Tooling" title="Technology Stack">
            <div className="overflow-x-auto">
              <table className="w-full text-sm bg-white rounded-lg shadow-sm border border-gray-200">
                <thead className="bg-gray-100 text-gray-600 text-left">
                  <tr>
                    <th className="p-3">Tier</th>
                    <th className="p-3">Technology</th>
                    <th className="p-3">Version</th>
                    <th className="p-3">Purpose</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {[
                    ["Frontend", "React", "18.2", "SPA UI (Create React App)"],
                    ["Frontend", "react-router-dom", "7.4", "Client-side routing"],
                    ["Frontend", "Tailwind CSS", "3.4", "Styling"],
                    ["Backend", "Java", "17", "Language"],
                    ["Backend", "Spring Boot", "3.1.4", "Web, Data JPA, Security"],
                    ["Backend", "jjwt", "0.12.6", "JWT (HS256)"],
                    ["Backend", "Razorpay SDK", "1.4.1", "Payments (scaffolded)"],
                    ["Backend", "Spring Kafka", "—", "Eventing (disabled)"],
                    ["Database", "MySQL", "8.x", "Relational store"],
                    ["Build", "Maven", "wrapper", "Backend build"],
                  ].map((row, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="p-3"><Pill color="indigo">{row[0]}</Pill></td>
                      <td className="p-3 font-medium">{row[1]}</td>
                      <td className="p-3 text-gray-500">{row[2]}</td>
                      <td className="p-3 text-gray-600">{row[3]}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Section>

          {/* STRUCTURE */}
          <Section id="structure" kicker="Code map" title="Project Structure">
            <div className="grid md:grid-cols-2 gap-4">
              <Card title="Backend" accent="emerald">
                <pre className="text-xs text-gray-700 whitespace-pre-wrap leading-relaxed">{`com.carrental
├── CarRentalSystemApplication
├── config/
│   ├── SecurityConfig
│   ├── JwtRequestFilter
│   ├── JwtUtil
│   └── CustomUserDetailsService
├── controllers/
│   ├── UserController
│   ├── VehicleController
│   ├── ReservationController
│   ├── PaymentController
│   └── WebhookController
├── services/
│   ├── UserService
│   ├── VehicleService
│   ├── ReservationService
│   └── PaymentService
├── respositories/
│   ├── UserRepository
│   ├── VehicleRepository
│   └── ReservationRepository
└── models/  (entities, DTOs, enums)`}</pre>
              </Card>
              <Card title="Frontend" accent="blue">
                <pre className="text-xs text-gray-700 whitespace-pre-wrap leading-relaxed">{`src/
├── index.js / App.js      (router + AuthProvider)
├── context/
│   └── AuthContext.js     (user, token, login/logout)
├── pages/
│   ├── Home.js
│   ├── SignUpPage.js
│   ├── CarRentalPage.js   (vehicle listing)
│   ├── BookingPage.js     (booking + payment)
│   ├── UserPanelPage.js   (dashboard/profile)
│   └── DocsPage.js        (this page)
├── components/
│   ├── Navbar, Footer, HeroSection ...
│   ├── SignIn.js / SignUp.js
│   ├── CarRental.js       (vehicle card)
│   ├── Dashboard.js       (reservations)
│   └── Profile.js
└── styles/global.css`}</pre>
              </Card>
            </div>
          </Section>

          {/* DATA MODEL */}
          <Section id="data" kicker="Persistence" title="Data Model">
            <p className="mb-6 leading-relaxed">
              Three core tables. A <strong>reservation</strong> links one <strong>user</strong> to one{" "}
              <strong>vehicle</strong> for a time window. Schema is auto-managed by Hibernate.
            </p>

            {/* ERD */}
            <Card>
              <div className="flex flex-col md:flex-row items-stretch justify-center gap-4">
                <div className="flex-1 rounded-lg border-2 border-purple-300 bg-purple-50 p-4">
                  <h5 className="font-bold text-purple-800 mb-2">users</h5>
                  <ul className="text-xs text-purple-900 space-y-0.5">
                    <li>🔑 id (PK)</li>
                    <li>name</li>
                    <li>email</li>
                    <li>password (BCrypt)</li>
                    <li>role (USER / ADMIN)</li>
                  </ul>
                </div>
                <div className="flex items-center justify-center text-gray-400 font-mono text-sm">1 ──&lt; *</div>
                <div className="flex-1 rounded-lg border-2 border-indigo-300 bg-indigo-50 p-4">
                  <h5 className="font-bold text-indigo-800 mb-2">reservations</h5>
                  <ul className="text-xs text-indigo-900 space-y-0.5">
                    <li>🔑 id (PK)</li>
                    <li>🔗 user_id (FK)</li>
                    <li>🔗 vehicle_id (FK)</li>
                    <li>startDate / endDate</li>
                    <li>totalCost</li>
                    <li>status</li>
                    <li>paymentStatus</li>
                  </ul>
                </div>
                <div className="flex items-center justify-center text-gray-400 font-mono text-sm">* &gt;── 1</div>
                <div className="flex-1 rounded-lg border-2 border-emerald-300 bg-emerald-50 p-4">
                  <h5 className="font-bold text-emerald-800 mb-2">vehicles</h5>
                  <ul className="text-xs text-emerald-900 space-y-0.5">
                    <li>🔑 id (PK)</li>
                    <li>vehicleNumber</li>
                    <li>companyName / modelName</li>
                    <li>vehicleType (CAR / BIKE)</li>
                    <li>status (AVAILABLE / RENTED)</li>
                    <li>dailyRentalCost / hourlyRentalCost</li>
                    <li>imageUrl</li>
                  </ul>
                </div>
              </div>
            </Card>

            {/* enums */}
            <h3 className="text-xl font-semibold mt-8 mb-4">Enumerations</h3>
            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-3">
              {[
                ["VehicleType", ["CAR", "BIKE"], "emerald"],
                ["VehicleStatus", ["AVAILABLE", "RENTED"], "blue"],
                ["ReservationStatus", ["SCHEDULED", "INPROGRESS", "COMPLETED", "CANCELLED"], "indigo"],
                ["PaymentStatus", ["PENDING", "PAID", "FAILED"], "amber"],
              ].map(([name, vals, c]) => (
                <Card key={name} title={name} accent={c}>
                  <div className="flex flex-wrap gap-1">
                    {vals.map((v) => (
                      <span key={v} className={`text-xs px-2 py-0.5 rounded bg-${c}-100 text-${c}-700`}>{v}</span>
                    ))}
                  </div>
                </Card>
              ))}
            </div>
          </Section>

          {/* API */}
          <Section id="api" kicker="Contracts" title="API Reference">
            <p className="mb-6 leading-relaxed">
              Base URL <code>http://localhost:8080</code>. All endpoints require an{" "}
              <code>Authorization: Bearer &lt;JWT&gt;</code> header <strong>except</strong> register and login.
            </p>

            {[
              {
                group: "User & Auth — /api/users",
                accent: "rose",
                rows: [
                  ["POST", "/register", "Public", "Create account (role forced to USER, password BCrypt-hashed)"],
                  ["POST", "/login", "Public", "Authenticate → returns { token, user }"],
                  ["POST", "/update-password", "Auth", "Update password (email, newPassword, confirmPassword)"],
                  ["GET", "/{email}", "Auth", "Fetch user by email"],
                ],
              },
              {
                group: "Vehicles — /api/vehicles",
                accent: "emerald",
                rows: [
                  ["GET", "/", "Auth", "List all vehicles"],
                  ["GET", "/{id}", "Auth", "Get vehicle by id"],
                  ["GET", "/available", "Auth", "List AVAILABLE vehicles"],
                  ["POST", "/", "Auth", "Add a vehicle"],
                  ["PUT", "/{id}", "Auth", "Update a vehicle"],
                  ["DELETE", "/{id}", "Auth", "Delete a vehicle"],
                  ["POST", "/{id}/uploadImage", "Auth", "Upload vehicle image (multipart)"],
                ],
              },
              {
                group: "Reservations — /api/reservations",
                accent: "indigo",
                rows: [
                  ["GET", "/", "Auth", "List all reservations"],
                  ["GET", "/{id}", "Auth", "Get reservation by id"],
                  ["GET", "/user/{userId}", "Auth", "List a user's reservations"],
                  ["POST", "/book", "Auth", "Create booking (userId, vehicleId, startDate, endDate)"],
                  ["PUT", "/{id}/status", "Auth", "Update reservation status"],
                  ["DELETE", "/{id}/cancel", "Auth", "Cancel booking → frees vehicle"],
                  ["GET", "/{id}/pay", "Auth", "Redirect to dummy payment gateway"],
                ],
              },
              {
                group: "Payments & Webhook",
                accent: "amber",
                rows: [
                  ["POST", "/api/payments/confirm", "Auth", "Confirm payment (reservationId, status)"],
                  ["POST", "/webhook/razorpay", "Auth", "Razorpay webhook (stub)"],
                ],
              },
            ].map((blk) => (
              <div key={blk.group} className="mb-6">
                <h3 className={`text-lg font-semibold mb-2 text-${blk.accent}-700`}>{blk.group}</h3>
                <div className="overflow-x-auto">
                  <table className="w-full text-sm bg-white rounded-lg shadow-sm border border-gray-200">
                    <tbody className="divide-y divide-gray-100">
                      {blk.rows.map((r, i) => (
                        <tr key={i} className="hover:bg-gray-50">
                          <td className="p-3 w-20"><Method m={r[0]} /></td>
                          <td className="p-3 font-mono text-gray-800 whitespace-nowrap">{r[1]}</td>
                          <td className="p-3 w-20">
                            <span className={`text-xs ${r[2] === "Public" ? "text-emerald-600" : "text-gray-400"}`}>
                              {r[2] === "Public" ? "🔓 Public" : "🔒 Auth"}
                            </span>
                          </td>
                          <td className="p-3 text-gray-600">{r[3]}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </Section>

          {/* FLOWS */}
          <Section id="flows" kicker="How it works" title="Key Flows">
            {/* Auth */}
            <h3 className="text-xl font-semibold mb-4">1 · Authentication (Login)</h3>
            <Card>
              <div className="flex flex-col gap-2">
                {[
                  ["Browser", "User submits email + password from SignIn form", "blue"],
                  ["POST /api/users/login", "Request hits UserController", "rose"],
                  ["AuthenticationManager", "Validates credentials via BCrypt + CustomUserDetailsService", "amber"],
                  ["JwtUtil.generateToken()", "Signs an HS256 JWT with the user email", "emerald"],
                  ["Response { token, user }", "200 OK returned to the browser", "indigo"],
                  ["AuthContext.login()", "Stores token + user in localStorage; future calls send Bearer token", "purple"],
                ].map(([t, d, c], i, arr) => (
                  <div key={t}>
                    <div className={`rounded-lg border-l-4 border-${c}-400 bg-${c}-50 px-4 py-2`}>
                      <span className="font-mono font-semibold text-gray-800 text-sm">{t}</span>
                      <p className="text-xs text-gray-600">{d}</p>
                    </div>
                    {i < arr.length - 1 && <div className="text-center text-gray-300 text-lg leading-none">↓</div>}
                  </div>
                ))}
              </div>
            </Card>

            {/* Booking */}
            <h3 className="text-xl font-semibold mt-10 mb-4">2 · Book a Vehicle &amp; Pay</h3>
            <Card>
              <div className="flex flex-col gap-2">
                {[
                  ["CarRentalPage", "GET /api/vehicles → user picks a vehicle card", "blue"],
                  ["BookingPage", "GET /api/vehicles/{id} → user selects start/end datetime", "blue"],
                  ["POST /api/reservations/book", "ReservationService validates vehicle is AVAILABLE", "indigo"],
                  ["Cost calculation", "totalCost = (days × dailyCost) + (extra hours × hourlyCost)", "amber"],
                  ["Persist", "Reservation = SCHEDULED / PENDING · Vehicle → RENTED", "emerald"],
                  ["Dummy payment gateway", "POST /api/payments/confirm?status=SUCCESS", "rose"],
                  ["On SUCCESS", "Reservation → PAID + COMPLETED · Vehicle → AVAILABLE", "purple"],
                ].map(([t, d, c], i, arr) => (
                  <div key={t}>
                    <div className={`rounded-lg border-l-4 border-${c}-400 bg-${c}-50 px-4 py-2`}>
                      <span className="font-mono font-semibold text-gray-800 text-sm">{t}</span>
                      <p className="text-xs text-gray-600">{d}</p>
                    </div>
                    {i < arr.length - 1 && <div className="text-center text-gray-300 text-lg leading-none">↓</div>}
                  </div>
                ))}
              </div>
            </Card>

            {/* Reservation state machine */}
            <h3 className="text-xl font-semibold mt-10 mb-4">3 · Reservation State Machine</h3>
            <Card>
              <div className="flex flex-wrap items-center gap-3 justify-center">
                <Box color="indigo">SCHEDULED</Box>
                <Arrow label="pay success" />
                <Box color="emerald">COMPLETED<br /><span className="text-xs font-normal">PAID</span></Box>
                <span className="mx-2 text-gray-300">|</span>
                <Box color="indigo">SCHEDULED</Box>
                <Arrow label="cancel" />
                <Box color="rose">CANCELLED<br /><span className="text-xs font-normal">vehicle freed</span></Box>
              </div>
            </Card>

            {/* Dashboard */}
            <h3 className="text-xl font-semibold mt-10 mb-4">4 · Dashboard</h3>
            <Card>
              <div className="flex flex-col sm:flex-row items-center justify-center gap-3">
                <Box color="blue">UserPanel → Dashboard</Box>
                <Arrow label="Bearer JWT" />
                <Box color="indigo">GET /api/reservations/user/&#123;userId&#125;</Box>
                <Arrow />
                <Box color="emerald">Renders user's bookings table</Box>
              </div>
            </Card>
          </Section>

          {/* SECURITY */}
          <Section id="security" kicker="Cross-cutting" title="Security Design">
            <div className="grid md:grid-cols-2 gap-4">
              <Card title="Authentication & Tokens" accent="rose">
                <ul className="text-sm space-y-2 text-gray-600">
                  <li>✅ Stateless JWT (HS256), sent as <code>Authorization: Bearer</code></li>
                  <li>✅ Passwords hashed with BCrypt</li>
                  <li>✅ <code>JwtRequestFilter</code> validates the token on every request</li>
                  <li>✅ Session policy is <code>STATELESS</code>; CSRF disabled (API style)</li>
                  <li>✅ CORS allows <code>http://localhost:3000</code></li>
                </ul>
              </Card>
              <Card title="Request authorization" accent="indigo">
                <ul className="text-sm space-y-2 text-gray-600">
                  <li><code>/api/users/register</code> &amp; <code>/login</code> → public</li>
                  <li>Everything else → authenticated</li>
                  <li>Roles (USER / ADMIN) exist on the user record</li>
                  <li>⚠️ Method-level role checks are <strong>not</strong> actively enforced</li>
                </ul>
              </Card>
            </div>
          </Section>

          {/* SETUP */}
          <Section id="setup" kicker="Run it locally" title="Setup & Run">
            <div className="grid md:grid-cols-2 gap-4">
              <Card title="Backend (port 8080)" accent="emerald">
                <pre className="text-xs bg-gray-900 text-gray-100 rounded-lg p-4 overflow-x-auto">{`cd car-rental-system
./mvnw clean install
./mvnw spring-boot:run`}</pre>
                <p className="text-xs text-gray-500 mt-2">Requires Java 17 + a running MySQL with DB <code>car_rental</code>.</p>
              </Card>
              <Card title="Frontend (port 3000)" accent="blue">
                <pre className="text-xs bg-gray-900 text-gray-100 rounded-lg p-4 overflow-x-auto">{`cd car-rental-frontend
npm install
npm start`}</pre>
                <p className="text-xs text-gray-500 mt-2">Opens the SPA; this docs page is at <code>/docs</code>.</p>
              </Card>
            </div>
          </Section>

          {/* ISSUES */}
          <Section id="issues" kicker="Be aware" title="Known Issues & Recommendations">
            <div className="space-y-2">
              {[
                ["Hard-coded secrets", "JWT key, DB password and Razorpay keys live in source/properties — externalize to env vars."],
                ["JWT expiry is 60 seconds", "EXPIRATION_TIME = 1000 * 60; the comment claims 1 hour. Fix the value, add refresh tokens."],
                ["No role enforcement", "Admin/vehicle mutation endpoints lack @PreAuthorize role checks."],
                ["SignUp auto-login is broken", "SignUp.js calls login(userData) without a token; register also returns the password hash."],
                ["UserResponse mis-mapped", "DTO is annotated @Entity on the users table — should be a plain POJO/record."],
                ["BookingPage hard-codes userId = 1", "Should use the authenticated user id from AuthContext."],
                ["Field mismatches", "CarRentalPage search uses car.name; Profile.js calls a non-existent PUT /api/users/{id}."],
                ["Razorpay & Kafka unused", "Scaffolded but disabled — implement fully or remove."],
                ["Non-standard package layout", "package src.main.java.com.carrental → normalize to com.carrental."],
              ].map(([t, d]) => (
                <div key={t} className="bg-white rounded-lg border border-gray-200 shadow-sm px-4 py-3">
                  <p className="font-semibold text-gray-800 text-sm flex items-center gap-2">
                    <span className="text-amber-500">⚠️</span> {t}
                  </p>
                  <p className="text-sm text-gray-600 ml-6">{d}</p>
                </div>
              ))}
            </div>
          </Section>

          <footer className="border-t border-gray-200 pt-6 text-center text-sm text-gray-400">
            Drivee — Car &amp; Bike Rental System · Documentation generated from source (HLD + LLD)
          </footer>
        </main>
      </div>
    </div>
  );
};

export default DocsPage;
