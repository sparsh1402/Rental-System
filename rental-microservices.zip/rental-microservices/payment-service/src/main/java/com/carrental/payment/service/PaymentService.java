package com.carrental.payment.service;

import com.carrental.common.events.PaymentCompletedEvent;
import com.carrental.common.events.PaymentFailedEvent;
import com.carrental.payment.messaging.PaymentEventPublisher;
import com.carrental.payment.model.Payment;
import com.carrental.payment.model.PaymentRecordStatus;
import com.carrental.payment.repository.PaymentRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.NoSuchElementException;

@Service
public class PaymentService {

    private static final Logger log = LoggerFactory.getLogger(PaymentService.class);

    private final PaymentRepository paymentRepository;
    private final PaymentEventPublisher publisher;

    public PaymentService(PaymentRepository paymentRepository, PaymentEventPublisher publisher) {
        this.paymentRepository = paymentRepository;
        this.publisher = publisher;
    }

    /** Idempotently creates a PENDING payment when a reservation is created. */
    @Transactional
    public void createPending(Long reservationId, Long vehicleId, double amount) {
        if (paymentRepository.existsByReservationId(reservationId)) {
            log.debug("Payment already exists for reservation {} (idempotent skip)", reservationId);
            return;
        }
        Payment payment = new Payment();
        payment.setReservationId(reservationId);
        payment.setVehicleId(vehicleId);
        payment.setAmount(amount);
        payment.setStatus(PaymentRecordStatus.PENDING);
        paymentRepository.save(payment);
        log.info("Created PENDING payment for reservation {}", reservationId);
    }

    /** Confirms a payment outcome (SUCCESS/FAILED) and emits the saga event. */
    @Transactional
    public String confirm(Long reservationId, String status) {
        Payment payment = paymentRepository.findByReservationId(reservationId)
                .orElseThrow(() -> new NoSuchElementException(
                        "No payment initialized for reservation " + reservationId + " yet"));

        if (payment.getStatus() != PaymentRecordStatus.PENDING) {
            return "Payment already " + payment.getStatus();
        }

        boolean success = "SUCCESS".equalsIgnoreCase(status);
        payment.setStatus(success ? PaymentRecordStatus.PAID : PaymentRecordStatus.FAILED);
        payment.setUpdatedAt(Instant.now());
        paymentRepository.save(payment);

        if (success) {
            publisher.publishCompleted(new PaymentCompletedEvent(
                    reservationId, payment.getId(), payment.getVehicleId(), payment.getAmount(), Instant.now()));
            return "Payment Successful!";
        } else {
            publisher.publishFailed(new PaymentFailedEvent(
                    reservationId, payment.getVehicleId(), "Declined at gateway", Instant.now()));
            return "Payment Failed!";
        }
    }
}
