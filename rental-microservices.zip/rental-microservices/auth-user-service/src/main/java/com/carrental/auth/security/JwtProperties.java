package com.carrental.auth.security;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "security.jwt")
public class JwtProperties {

    /** HMAC signing secret. Must match the gateway's secret. */
    private String secret = "change-me-this-secret-must-be-at-least-32-characters-long";

    /** Token lifetime in milliseconds. Default 1 hour (the monolith mistakenly used 60s). */
    private long expirationMs = 3_600_000L;

    public String getSecret() {
        return secret;
    }

    public void setSecret(String secret) {
        this.secret = secret;
    }

    public long getExpirationMs() {
        return expirationMs;
    }

    public void setExpirationMs(long expirationMs) {
        this.expirationMs = expirationMs;
    }
}
