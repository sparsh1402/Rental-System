package com.carrental.reservation.client;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.NoSuchElementException;

@Component
public class UserClient {

    private final RestClient restClient;

    public UserClient(ClientProperties properties) {
        this.restClient = RestClient.create(properties.getAuthUrl());
    }

    public UserDto getUser(Long id) {
        UserDto user = restClient.get()
                .uri("/api/users/{id}", id)
                .retrieve()
                .body(UserDto.class);
        if (user == null) {
            throw new NoSuchElementException("User not found: " + id);
        }
        return user;
    }
}
