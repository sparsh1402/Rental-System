package com.carrental.notification.messaging;

import com.carrental.common.events.KafkaTopics;
import com.carrental.common.events.ReservationCancelledEvent;
import com.carrental.common.events.ReservationConfirmedEvent;
import com.carrental.common.events.ReservationCreatedEvent;
import com.carrental.notification.service.NotificationService;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@KafkaListener(topics = KafkaTopics.RESERVATION_EVENTS, groupId = "notification-service")
public class ReservationEventsListener {

    private final NotificationService notificationService;

    public ReservationEventsListener(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @KafkaHandler
    public void onCreated(ReservationCreatedEvent e) {
        notificationService.notify("res-created-" + e.reservationId(),
                "Booking #" + e.reservationId() + " created for vehicle " + e.vehicleId()
                        + ". Please complete payment of " + e.totalCost() + ".");
    }

    @KafkaHandler
    public void onConfirmed(ReservationConfirmedEvent e) {
        notificationService.notify("res-confirmed-" + e.reservationId(),
                "Booking #" + e.reservationId() + " confirmed. Enjoy your ride!");
    }

    @KafkaHandler
    public void onCancelled(ReservationCancelledEvent e) {
        notificationService.notify("res-cancelled-" + e.reservationId(),
                "Booking #" + e.reservationId() + " was cancelled. Reason: " + e.reason());
    }

    @KafkaHandler(isDefault = true)
    public void onOther(Object e) {
        // ignore unknown types
    }
}
