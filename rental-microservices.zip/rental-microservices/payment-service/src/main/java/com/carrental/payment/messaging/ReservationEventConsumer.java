package com.carrental.payment.messaging;

import com.carrental.common.events.KafkaTopics;
import com.carrental.common.events.ReservationCreatedEvent;
import com.carrental.payment.service.PaymentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * On reservation creation, initialize a PENDING payment so the user can later
 * confirm it. Other reservation event types are ignored here.
 */
@Component
@KafkaListener(topics = KafkaTopics.RESERVATION_EVENTS, groupId = "payment-service")
public class ReservationEventConsumer {

    private static final Logger log = LoggerFactory.getLogger(ReservationEventConsumer.class);

    private final PaymentService paymentService;

    public ReservationEventConsumer(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @KafkaHandler
    public void onCreated(ReservationCreatedEvent event) {
        log.info("Initializing payment for reservation {}", event.reservationId());
        paymentService.createPending(event.reservationId(), event.vehicleId(), event.totalCost());
    }

    @KafkaHandler(isDefault = true)
    public void onOther(Object event) {
        log.debug("Ignoring reservation event type {}", event.getClass().getSimpleName());
    }
}
