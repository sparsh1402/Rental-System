package com.carrental.reservation.dto;

import com.carrental.reservation.model.PaymentStatus;
import com.carrental.reservation.model.Reservation;
import com.carrental.reservation.model.ReservationStatus;

public record ReservationResponse(
        Long id,
        Long userId,
        Long vehicleId,
        VehicleInfo vehicle,
        String startDate,
        String endDate,
        double totalCost,
        ReservationStatus status,
        PaymentStatus paymentStatus
) {
    public static ReservationResponse from(Reservation r, VehicleInfo vehicle) {
        return new ReservationResponse(
                r.getId(), r.getUserId(), r.getVehicleId(), vehicle,
                String.valueOf(r.getStartDate()), String.valueOf(r.getEndDate()),
                r.getTotalCost(), r.getStatus(), r.getPaymentStatus());
    }
}
