package com.carrental.reservation.model;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * One row per vehicle, used purely as a pessimistic-lock target so that
 * concurrent booking attempts for the same vehicle are serialized
 * (prevents double-booking). The id equals the vehicleId.
 */
@Entity
@Table(name = "vehicle_locks")
@Getter
@Setter
@NoArgsConstructor
public class VehicleLock {

    @Id
    private Long id;

    public VehicleLock(Long id) {
        this.id = id;
    }
}
