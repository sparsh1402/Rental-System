import { useContext, useEffect, useState, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../components/Navbar";
import LocationMap from "../components/LocationMap";
import { AuthContext } from "../context/AuthContext";
import { apiFetch, apiJson } from "../api/client";

const EMPTY_FORM = {
  vehicleNumber: "",
  companyName: "",
  modelName: "",
  vehicleType: "CAR",
  status: "AVAILABLE",
  dailyRentalCost: "",
  hourlyRentalCost: "",
  location: "",
  latitude: "",
  longitude: "",
};

const AdminPage = () => {
  const { isLogged, user, token, logout } = useContext(AuthContext);
  const navigate = useNavigate();

  const [vehicles, setVehicles] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editingId, setEditingId] = useState(null);
  const [imageFile, setImageFile] = useState(null);
  const [message, setMessage] = useState(null);
  const [error, setError] = useState(null);

  const isAdmin = isLogged && user?.role === "ADMIN";

  const loadVehicles = useCallback(async () => {
    try {
      setVehicles(await apiJson("/api/vehicles", { skipAuth: true }));
    } catch (e) {
      setError(e.message);
    }
  }, []);

  useEffect(() => {
    loadVehicles();
  }, [loadVehicles]);

  const handleChange = (e) => setForm({ ...form, [e.target.name]: e.target.value });

  const handleMapPick = (lat, lng) =>
    setForm((f) => ({ ...f, latitude: lat.toFixed(6), longitude: lng.toFixed(6) }));

  const resetForm = () => {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setImageFile(null);
  };

  const startEdit = (v) => {
    setEditingId(v.id);
    setForm({
      vehicleNumber: v.vehicleNumber ?? "",
      companyName: v.companyName ?? "",
      modelName: v.modelName ?? "",
      vehicleType: v.vehicleType ?? "CAR",
      status: v.status ?? "AVAILABLE",
      dailyRentalCost: v.dailyRentalCost ?? "",
      hourlyRentalCost: v.hourlyRentalCost ?? "",
      location: v.location ?? "",
      latitude: v.latitude ?? "",
      longitude: v.longitude ?? "",
    });
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);
    setMessage(null);

    const payload = {
      ...form,
      dailyRentalCost: parseFloat(form.dailyRentalCost) || 0,
      hourlyRentalCost: parseFloat(form.hourlyRentalCost) || 0,
      latitude: form.latitude === "" ? null : parseFloat(form.latitude),
      longitude: form.longitude === "" ? null : parseFloat(form.longitude),
    };

    try {
      const path = editingId ? `/api/vehicles/${editingId}` : "/api/vehicles";
      const saved = await apiJson(path, {
        method: editingId ? "PUT" : "POST",
        body: JSON.stringify(payload),
      });

      if (imageFile) {
        const fd = new FormData();
        fd.append("file", imageFile);
        const upload = await apiFetch(`/api/vehicles/${saved.id}/uploadImage`, {
          method: "POST",
          body: fd,
        });
        if (!upload.ok) throw new Error("Image upload failed");
      }

      setMessage(editingId ? "Vehicle updated." : "Vehicle created.");
      resetForm();
      loadVehicles();
    } catch (e2) {
      setError(e2.message);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this vehicle?")) return;
    try {
      await apiJson(`/api/vehicles/${id}`, { method: "DELETE" });
      setMessage("Vehicle deleted.");
      loadVehicles();
    } catch (e) {
      setError(e.message);
    }
  };

  const handleLogout = () => {
    logout();
    navigate("/");
  };

  if (!isAdmin) {
    return (
      <div className="min-h-screen bg-gray-100">
        <Navbar onLogout={handleLogout} />
        <div className="max-w-xl mx-auto mt-20 bg-white p-8 rounded-lg shadow text-center">
          <h1 className="text-2xl font-bold mb-2">Admin access required</h1>
          <p className="text-gray-600">
            Please sign in with an administrator account to manage vehicles.
          </p>
        </div>
      </div>
    );
  }

  const lat = form.latitude === "" ? undefined : parseFloat(form.latitude);
  const lng = form.longitude === "" ? undefined : parseFloat(form.longitude);

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar onLogout={handleLogout} />
      <div className="max-w-6xl mx-auto px-6 py-8">
        <h1 className="text-3xl font-bold mb-6">Admin · Manage Vehicles</h1>

        {message && <div className="mb-4 p-3 rounded bg-green-100 text-green-700">{message}</div>}
        {error && <div className="mb-4 p-3 rounded bg-red-100 text-red-700">{error}</div>}

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Form */}
          <form onSubmit={handleSubmit} className="bg-white p-6 rounded-lg shadow space-y-3">
            <h2 className="text-xl font-semibold">
              {editingId ? `Edit vehicle #${editingId}` : "Add a vehicle"}
            </h2>

            <div className="grid grid-cols-2 gap-3">
              <input name="vehicleNumber" value={form.vehicleNumber} onChange={handleChange}
                placeholder="Vehicle number" className="border p-2 rounded" required />
              <select name="vehicleType" value={form.vehicleType} onChange={handleChange}
                className="border p-2 rounded">
                <option value="CAR">CAR</option>
                <option value="BIKE">BIKE</option>
              </select>
              <input name="companyName" value={form.companyName} onChange={handleChange}
                placeholder="Company (e.g. Tesla)" className="border p-2 rounded" required />
              <input name="modelName" value={form.modelName} onChange={handleChange}
                placeholder="Model (e.g. Model 3)" className="border p-2 rounded" required />
              <input name="dailyRentalCost" type="number" step="0.01" value={form.dailyRentalCost}
                onChange={handleChange} placeholder="Daily cost" className="border p-2 rounded" required />
              <input name="hourlyRentalCost" type="number" step="0.01" value={form.hourlyRentalCost}
                onChange={handleChange} placeholder="Hourly cost" className="border p-2 rounded" required />
              <select name="status" value={form.status} onChange={handleChange}
                className="border p-2 rounded">
                <option value="AVAILABLE">AVAILABLE</option>
                <option value="RENTED">RENTED</option>
              </select>
              <input name="location" value={form.location} onChange={handleChange}
                placeholder="Pickup location (city/branch)" className="border p-2 rounded" />
            </div>

            <div>
              <label className="block text-sm text-gray-600 mb-1">
                Pick location on the map (click to drop a pin)
              </label>
              <LocationMap lat={lat} lng={lng} onChange={handleMapPick} height={240} />
              <div className="grid grid-cols-2 gap-3 mt-2">
                <input name="latitude" value={form.latitude} onChange={handleChange}
                  placeholder="Latitude" className="border p-2 rounded" />
                <input name="longitude" value={form.longitude} onChange={handleChange}
                  placeholder="Longitude" className="border p-2 rounded" />
              </div>
            </div>

            <div>
              <label className="block text-sm text-gray-600 mb-1">Image</label>
              <input type="file" accept="image/*" onChange={(e) => setImageFile(e.target.files[0])} />
            </div>

            <div className="flex gap-3">
              <button type="submit" className="bg-black text-white px-5 py-2 rounded">
                {editingId ? "Update" : "Create"}
              </button>
              {editingId && (
                <button type="button" onClick={resetForm} className="bg-gray-200 px-5 py-2 rounded">
                  Cancel
                </button>
              )}
            </div>
          </form>

          {/* List */}
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Vehicles ({vehicles.length})</h2>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-gray-100 text-left">
                    <th className="p-2">#</th>
                    <th className="p-2">Vehicle</th>
                    <th className="p-2">Location</th>
                    <th className="p-2">Status</th>
                    <th className="p-2">Actions</th>
                  </tr>
                </thead>
                <tbody>
                  {vehicles.map((v) => (
                    <tr key={v.id} className="border-b">
                      <td className="p-2">{v.id}</td>
                      <td className="p-2">{v.companyName} {v.modelName}</td>
                      <td className="p-2">{v.location || "—"}</td>
                      <td className="p-2">{v.status}</td>
                      <td className="p-2 space-x-2 whitespace-nowrap">
                        <button onClick={() => startEdit(v)} className="text-blue-600 hover:underline">Edit</button>
                        <button onClick={() => handleDelete(v.id)} className="text-red-600 hover:underline">Delete</button>
                      </td>
                    </tr>
                  ))}
                  {vehicles.length === 0 && (
                    <tr><td colSpan="5" className="p-3 text-center text-gray-500">No vehicles yet.</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminPage;
