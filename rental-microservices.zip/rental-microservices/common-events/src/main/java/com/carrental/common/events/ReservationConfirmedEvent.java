package com.carrental.common.events;

import java.time.Instant;

/**
 * Emitted by reservation-service after a successful payment confirms the booking
 * (status COMPLETED / PAID). Consumed by notification-service.
 */
public record ReservationConfirmedEvent(
        Long reservationId,
        Long userId,
        Long vehicleId,
        double totalCost,
        Instant occurredAt
) {
}
