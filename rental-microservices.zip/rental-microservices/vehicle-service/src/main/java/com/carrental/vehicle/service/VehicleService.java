package com.carrental.vehicle.service;

import com.carrental.vehicle.config.StorageProperties;
import com.carrental.vehicle.dto.VehicleRequest;
import com.carrental.vehicle.dto.VehicleResponse;
import com.carrental.vehicle.model.Vehicle;
import com.carrental.vehicle.model.VehicleStatus;
import com.carrental.vehicle.repository.VehicleRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.UUID;

@Service
public class VehicleService {

    private static final Logger log = LoggerFactory.getLogger(VehicleService.class);

    private final VehicleRepository vehicleRepository;
    private final StorageProperties storageProperties;

    public VehicleService(VehicleRepository vehicleRepository, StorageProperties storageProperties) {
        this.vehicleRepository = vehicleRepository;
        this.storageProperties = storageProperties;
    }

    @Transactional(readOnly = true)
    public List<VehicleResponse> getAll() {
        return vehicleRepository.findAll().stream().map(VehicleResponse::from).toList();
    }

    @Transactional(readOnly = true)
    public VehicleResponse getById(Long id) {
        return vehicleRepository.findById(id).map(VehicleResponse::from)
                .orElseThrow(() -> new NoSuchElementException("Vehicle not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<VehicleResponse> getAvailable() {
        return vehicleRepository.findByStatus(VehicleStatus.AVAILABLE).stream()
                .map(VehicleResponse::from).toList();
    }

    @Transactional
    public VehicleResponse add(VehicleRequest request) {
        Vehicle vehicle = new Vehicle();
        apply(vehicle, request);
        if (request.status() != null) {
            vehicle.setStatus(request.status());
        }
        return VehicleResponse.from(vehicleRepository.save(vehicle));
    }

    @Transactional
    public VehicleResponse update(Long id, VehicleRequest request) {
        Vehicle vehicle = vehicleRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Vehicle not found: " + id));
        apply(vehicle, request);
        if (request.status() != null) {
            vehicle.setStatus(request.status());
        }
        return VehicleResponse.from(vehicleRepository.save(vehicle));
    }

    @Transactional
    public void delete(Long id) {
        vehicleRepository.deleteById(id);
    }

    @Transactional
    public String uploadImage(Long id, MultipartFile file) throws IOException {
        Vehicle vehicle = vehicleRepository.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Vehicle not found: " + id));

        String fileName = UUID.randomUUID() + "_" + file.getOriginalFilename();
        Path filePath = Paths.get(storageProperties.getUploadDir(), fileName);
        Files.createDirectories(filePath.getParent());
        Files.write(filePath, file.getBytes());

        String imageUrl = storageProperties.getPublicBaseUrl() + "/" + storageProperties.getUploadDir() + "/" + fileName;
        vehicle.setImageUrl(imageUrl);
        vehicleRepository.save(vehicle);
        return imageUrl;
    }

    /**
     * Saga reaction: a vehicle moves to RENTED when a reservation is created and
     * back to AVAILABLE when the reservation is cancelled or payment fails.
     * Uses the entity @Version for optimistic locking against concurrent events.
     */
    @Transactional
    public void changeStatus(Long vehicleId, VehicleStatus status) {
        vehicleRepository.findById(vehicleId).ifPresentOrElse(vehicle -> {
            vehicle.setStatus(status);
            vehicleRepository.save(vehicle);
            log.info("Vehicle {} status -> {}", vehicleId, status);
        }, () -> log.warn("Saga event for unknown vehicle {}", vehicleId));
    }

    private void apply(Vehicle vehicle, VehicleRequest request) {
        vehicle.setVehicleNumber(request.vehicleNumber());
        vehicle.setCompanyName(request.companyName());
        vehicle.setModelName(request.modelName());
        vehicle.setVehicleType(request.vehicleType());
        vehicle.setDailyRentalCost(request.dailyRentalCost());
        vehicle.setHourlyRentalCost(request.hourlyRentalCost());
        vehicle.setLocation(request.location());
        vehicle.setLatitude(request.latitude());
        vehicle.setLongitude(request.longitude());
    }
}
