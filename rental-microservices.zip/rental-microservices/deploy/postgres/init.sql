-- Creates one logical database per microservice (database-per-service pattern
-- collapsed onto a single Postgres instance to save memory on the free tier).
-- Each service connects only to its own database.

CREATE DATABASE authdb;
CREATE DATABASE vehicledb;
CREATE DATABASE reservationdb;
CREATE DATABASE paymentdb;
