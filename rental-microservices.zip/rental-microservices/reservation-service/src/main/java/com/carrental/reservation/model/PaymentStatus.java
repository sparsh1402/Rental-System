package com.carrental.reservation.model;

public enum PaymentStatus {
    PENDING, PAID, FAILED
}
