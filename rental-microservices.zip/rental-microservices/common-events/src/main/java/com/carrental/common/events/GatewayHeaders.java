package com.carrental.common.events;

/**
 * Headers the API gateway injects after validating the JWT. Downstream services
 * trust these headers instead of re-parsing the token (edge authentication).
 */
public final class GatewayHeaders {

    private GatewayHeaders() {
    }

    public static final String USER_EMAIL = "X-Auth-User-Email";
    public static final String USER_ID = "X-Auth-User-Id";
    public static final String USER_ROLE = "X-Auth-User-Role";
}
