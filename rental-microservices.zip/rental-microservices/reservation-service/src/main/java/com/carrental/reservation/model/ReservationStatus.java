package com.carrental.reservation.model;

public enum ReservationStatus {
    SCHEDULED, INPROGRESS, COMPLETED, CANCELLED
}
