package com.carrental.notification.messaging;

import com.carrental.common.events.KafkaTopics;
import com.carrental.common.events.PaymentCompletedEvent;
import com.carrental.common.events.PaymentFailedEvent;
import com.carrental.notification.service.NotificationService;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@KafkaListener(topics = KafkaTopics.PAYMENT_EVENTS, groupId = "notification-service")
public class PaymentEventsListener {

    private final NotificationService notificationService;

    public PaymentEventsListener(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @KafkaHandler
    public void onCompleted(PaymentCompletedEvent e) {
        notificationService.notify("pay-completed-" + e.reservationId(),
                "Payment of " + e.amount() + " received for booking #" + e.reservationId() + ".");
    }

    @KafkaHandler
    public void onFailed(PaymentFailedEvent e) {
        notificationService.notify("pay-failed-" + e.reservationId(),
                "Payment failed for booking #" + e.reservationId() + ": " + e.reason());
    }

    @KafkaHandler(isDefault = true)
    public void onOther(Object e) {
        // ignore unknown types
    }
}
