package com.carrental.reservation.repository;

import com.carrental.reservation.model.Reservation;
import com.carrental.reservation.model.ReservationStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface ReservationRepository extends JpaRepository<Reservation, Long> {

    List<Reservation> findByUserId(Long userId);

    /**
     * Counts active reservations for a vehicle whose date range overlaps the
     * requested window. Overlap rule: existing.start < requested.end AND
     * existing.end > requested.start.
     */
    @Query("""
            select count(r) from Reservation r
            where r.vehicleId = :vehicleId
              and r.status in (com.carrental.reservation.model.ReservationStatus.SCHEDULED,
                               com.carrental.reservation.model.ReservationStatus.INPROGRESS)
              and r.startDate < :endDate
              and r.endDate > :startDate
            """)
    long countOverlapping(@Param("vehicleId") Long vehicleId,
                          @Param("startDate") LocalDateTime startDate,
                          @Param("endDate") LocalDateTime endDate);

    List<Reservation> findByStatusAndEndDateBefore(ReservationStatus status, LocalDateTime cutoff);
}
