package com.carrental.reservation.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@Table(name = "reservations", indexes = {
        @Index(name = "idx_res_user", columnList = "userId"),
        @Index(name = "idx_res_vehicle", columnList = "vehicleId")
})
@Getter
@Setter
@NoArgsConstructor
public class Reservation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Owned references are stored as ids only (no cross-service joins). */
    @Column(nullable = false)
    private Long userId;

    @Column(nullable = false)
    private Long vehicleId;

    private LocalDateTime startDate;
    private LocalDateTime endDate;

    private double totalCost;

    @Enumerated(EnumType.STRING)
    private ReservationStatus status = ReservationStatus.SCHEDULED;

    @Enumerated(EnumType.STRING)
    private PaymentStatus paymentStatus = PaymentStatus.PENDING;
}
