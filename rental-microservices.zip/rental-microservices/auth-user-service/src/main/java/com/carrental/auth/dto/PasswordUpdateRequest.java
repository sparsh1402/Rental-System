package com.carrental.auth.dto;

import jakarta.validation.constraints.NotBlank;

public record PasswordUpdateRequest(
        @NotBlank String email,
        @NotBlank String newPassword,
        @NotBlank String confirmPassword
) {
}
