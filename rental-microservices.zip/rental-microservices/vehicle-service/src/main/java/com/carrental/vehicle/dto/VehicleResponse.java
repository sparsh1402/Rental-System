package com.carrental.vehicle.dto;

import com.carrental.vehicle.model.Vehicle;
import com.carrental.vehicle.model.VehicleStatus;
import com.carrental.vehicle.model.VehicleType;

public record VehicleResponse(
        Long id,
        String vehicleNumber,
        String companyName,
        String modelName,
        VehicleType vehicleType,
        VehicleStatus status,
        double dailyRentalCost,
        double hourlyRentalCost,
        String imageUrl,
        String location,
        Double latitude,
        Double longitude
) {
    public static VehicleResponse from(Vehicle v) {
        return new VehicleResponse(
                v.getId(), v.getVehicleNumber(), v.getCompanyName(), v.getModelName(),
                v.getVehicleType(), v.getStatus(), v.getDailyRentalCost(),
                v.getHourlyRentalCost(), v.getImageUrl(),
                v.getLocation(), v.getLatitude(), v.getLongitude());
    }
}
