package com.carrental.notification.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Sends (here: logs) notifications. Demonstrates idempotent consumption: each
 * logical notification is keyed and processed at most once, so duplicate Kafka
 * deliveries do not produce duplicate notifications.
 */
@Service
public class NotificationService {

    private static final Logger log = LoggerFactory.getLogger(NotificationService.class);

    private final Set<String> processed = ConcurrentHashMap.newKeySet();

    public void notify(String dedupeKey, String message) {
        if (!processed.add(dedupeKey)) {
            log.debug("Duplicate notification ignored: {}", dedupeKey);
            return;
        }
        // In a real system this would call an email/SMS/push provider.
        log.info("NOTIFICATION [{}] -> {}", Thread.currentThread().getName(), message);
    }
}
