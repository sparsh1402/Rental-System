package com.carrental.reservation.service;

import com.carrental.common.events.ReservationCancelledEvent;
import com.carrental.common.events.ReservationConfirmedEvent;
import com.carrental.common.events.ReservationCreatedEvent;
import com.carrental.reservation.client.UserDto;
import com.carrental.reservation.client.UserClient;
import com.carrental.reservation.client.VehicleClient;
import com.carrental.reservation.client.VehicleDto;
import com.carrental.reservation.dto.ReservationResponse;
import com.carrental.reservation.dto.VehicleInfo;
import com.carrental.reservation.messaging.ReservationEventPublisher;
import com.carrental.reservation.model.Reservation;
import com.carrental.reservation.repository.ReservationRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;

@Service
public class ReservationService {

    private static final Logger log = LoggerFactory.getLogger(ReservationService.class);

    private final BookingTransactionService bookingTx;
    private final VehicleLockService vehicleLockService;
    private final ReservationRepository repo;
    private final VehicleClient vehicleClient;
    private final UserClient userClient;
    private final ReservationEventPublisher publisher;
    private final AuditService auditService;
    private final Executor aggregationExecutor;

    public ReservationService(BookingTransactionService bookingTx,
                              VehicleLockService vehicleLockService,
                              ReservationRepository repo,
                              VehicleClient vehicleClient,
                              UserClient userClient,
                              ReservationEventPublisher publisher,
                              AuditService auditService,
                              @Qualifier("aggregationExecutor") Executor aggregationExecutor) {
        this.bookingTx = bookingTx;
        this.vehicleLockService = vehicleLockService;
        this.repo = repo;
        this.vehicleClient = vehicleClient;
        this.userClient = userClient;
        this.publisher = publisher;
        this.auditService = auditService;
        this.aggregationExecutor = aggregationExecutor;
    }

    public ReservationResponse createReservation(Long userId, Long vehicleId, String startStr, String endStr) {
        LocalDateTime start = LocalDateTime.parse(startStr);
        LocalDateTime end = LocalDateTime.parse(endStr);
        if (!end.isAfter(start)) {
            throw new IllegalArgumentException("End date must be after start date");
        }

        // Parallel aggregation: validate user and vehicle concurrently (I/O-bound).
        CompletableFuture<UserDto> userF =
                CompletableFuture.supplyAsync(() -> userClient.getUser(userId), aggregationExecutor);
        CompletableFuture<VehicleDto> vehicleF =
                CompletableFuture.supplyAsync(() -> vehicleClient.getVehicle(vehicleId), aggregationExecutor);
        CompletableFuture.allOf(userF, vehicleF).join();

        UserDto user = userF.join();
        VehicleDto vehicle = vehicleF.join();
        log.info("Booking for user {} on vehicle {}", user.id(), vehicle.id());

        double cost = computeCost(start, end, vehicle);

        vehicleLockService.ensureExists(vehicleId);
        Reservation saved = bookingTx.lockAndSave(userId, vehicleId, start, end, cost);

        publisher.publishCreated(new ReservationCreatedEvent(
                saved.getId(), userId, vehicleId, cost, start.toString(), end.toString(), Instant.now()));
        auditService.recordBooking(saved.getId(), userId, vehicleId);

        return ReservationResponse.from(saved,
                new VehicleInfo(vehicle.companyName(), vehicle.modelName(), vehicle.imageUrl(), vehicle.location()));
    }

    public List<ReservationResponse> getUserReservations(Long userId) {
        return enrich(repo.findByUserId(userId));
    }

    public List<ReservationResponse> getAll() {
        return enrich(repo.findAll());
    }

    public ReservationResponse getById(Long id) {
        Reservation r = repo.findById(id)
                .orElseThrow(() -> new NoSuchElementException("Reservation not found: " + id));
        return ReservationResponse.from(r, vehicleInfo(r.getVehicleId()));
    }

    public void cancelReservation(Long id) {
        bookingTx.markCancelled(id, false).ifPresent(r ->
                publisher.publishCancelled(new ReservationCancelledEvent(
                        r.getId(), r.getVehicleId(), "Cancelled by user", Instant.now())));
    }

    /** Saga: payment succeeded -> confirm booking. */
    public void onPaymentCompleted(Long reservationId) {
        bookingTx.markConfirmed(reservationId).ifPresent(r ->
                publisher.publishConfirmed(new ReservationConfirmedEvent(
                        r.getId(), r.getUserId(), r.getVehicleId(), r.getTotalCost(), Instant.now())));
    }

    /** Saga compensation: payment failed -> cancel booking and release vehicle. */
    public void onPaymentFailed(Long reservationId, String reason) {
        bookingTx.markCancelled(reservationId, true).ifPresent(r ->
                publisher.publishCancelled(new ReservationCancelledEvent(
                        r.getId(), r.getVehicleId(), "Payment failed: " + reason, Instant.now())));
    }

    /**
     * Cancels still-SCHEDULED bookings whose end date has passed (e.g. payment
     * never completed). Invoked by the scheduled expiry job.
     *
     * @return number of reservations expired
     */
    public int expireStaleReservations() {
        List<Reservation> stale = repo.findByStatusAndEndDateBefore(
                com.carrental.reservation.model.ReservationStatus.SCHEDULED, LocalDateTime.now());
        int expired = 0;
        for (Reservation r : stale) {
            Optional<Reservation> cancelled = bookingTx.markCancelled(r.getId(), false);
            if (cancelled.isPresent()) {
                publisher.publishCancelled(new ReservationCancelledEvent(
                        r.getId(), r.getVehicleId(), "Expired (unpaid past end date)", Instant.now()));
                expired++;
            }
        }
        if (expired > 0) {
            log.info("Expired {} stale reservation(s)", expired);
        }
        return expired;
    }

    private double computeCost(LocalDateTime start, LocalDateTime end, VehicleDto vehicle) {
        long hours = Duration.between(start, end).toHours();
        long days = hours / 24;
        long remainderHours = hours % 24;
        return days * vehicle.dailyRentalCost() + remainderHours * vehicle.hourlyRentalCost();
    }

    /** Enriches a list of reservations with vehicle info, fetched in parallel. */
    private List<ReservationResponse> enrich(List<Reservation> reservations) {
        Map<Long, CompletableFuture<VehicleInfo>> futures = reservations.stream()
                .map(Reservation::getVehicleId)
                .distinct()
                .collect(Collectors.toMap(id -> id,
                        id -> CompletableFuture.supplyAsync(() -> vehicleInfo(id), aggregationExecutor)));

        CompletableFuture.allOf(futures.values().toArray(new CompletableFuture[0])).join();

        return reservations.stream()
                .map(r -> ReservationResponse.from(r, futures.get(r.getVehicleId()).join()))
                .toList();
    }

    private VehicleInfo vehicleInfo(Long vehicleId) {
        try {
            VehicleDto v = vehicleClient.getVehicle(vehicleId);
            return new VehicleInfo(v.companyName(), v.modelName(), v.imageUrl(), v.location());
        } catch (Exception e) {
            log.warn("Could not load vehicle {} for enrichment: {}", vehicleId, e.getMessage());
            return new VehicleInfo("Unknown", "Unknown", null, null);
        }
    }
}
