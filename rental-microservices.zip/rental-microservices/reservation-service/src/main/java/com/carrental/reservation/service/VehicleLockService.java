package com.carrental.reservation.service;

import com.carrental.reservation.model.VehicleLock;
import com.carrental.reservation.repository.VehicleLockRepository;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * Ensures a lock row exists for a vehicle in its OWN transaction so the booking
 * transaction can later take a clean pessimistic lock on it. Kept separate so a
 * unique-key clash on first creation never taints the booking transaction.
 */
@Service
public class VehicleLockService {

    private final VehicleLockRepository vehicleLockRepository;

    public VehicleLockService(VehicleLockRepository vehicleLockRepository) {
        this.vehicleLockRepository = vehicleLockRepository;
    }

    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void ensureExists(Long vehicleId) {
        if (!vehicleLockRepository.existsById(vehicleId)) {
            try {
                vehicleLockRepository.saveAndFlush(new VehicleLock(vehicleId));
            } catch (DataIntegrityViolationException ignored) {
                // Another thread created it first; that's fine.
            }
        }
    }
}
