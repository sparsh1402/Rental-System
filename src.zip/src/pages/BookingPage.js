import React, { useState, useEffect, useContext } from "react";
import { useSearchParams } from "react-router-dom";
import Navbar from "../components/Navbar";
import Footer from "../components/Footer";
import { AuthContext } from "../context/AuthContext";
import { API_BASE_URL } from "../config";
import LocationMap from "../components/LocationMap";

const BookingPage = () => {
  const [searchParams] = useSearchParams();
  const carId = searchParams.get("carId");
  const { user, token } = useContext(AuthContext);
  const userId = user?.id;

  const [car, setCar] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [showPaymentPopup, setShowPaymentPopup] = useState(false);
  
  useEffect(() => {
    if (!carId) {
      setError("Car ID is missing from the URL");
      setLoading(false);
      return;
    }
    const fetchCarDetails = async () => {
      try {
        const response = await fetch(`${API_BASE_URL}/api/vehicles/${carId}`);
        if (!response.ok) {
          throw new Error("Failed to fetch car details");
        }
        const data = await response.json();
        setCar(data);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    fetchCarDetails();
  }, [carId]);

  const [reservationId, setReservationId] = useState(null);

  const handleBooking = async () => {
    if (!startDate || !endDate) {
      alert("Please select start and end dates.");
      return;
    }
    if (!userId || !token) {
      alert("Please sign in to book a vehicle.");
      return;
    }

    const bookingUrl = `${API_BASE_URL}/api/reservations/book?userId=${userId}&vehicleId=${carId}&startDate=${startDate}&endDate=${endDate}`;

    try {
      const response = await fetch(bookingUrl, {
        method: "POST",
        headers: { "Authorization": `Bearer ${token}` },
      });

      if (!response.ok) {
        throw new Error("Booking failed. Please try again.");
      }

      const reservation = await response.json();
      setReservationId(reservation.id);
      setShowPaymentPopup(true);
    } catch (err) {
      alert(err.message);
    }
  };

  // Confirms payment via the payment-service, which drives the Kafka saga.
  const handlePayment = async (status) => {
    try {
      const response = await fetch(
        `${API_BASE_URL}/api/payments/confirm?reservationId=${reservationId}&status=${status}`,
        { method: "POST", headers: { "Authorization": `Bearer ${token}` } }
      );
      const data = await response.json();
      alert(data.message || "Payment processed.");
    } catch (err) {
      alert("Payment request failed.");
    } finally {
      setShowPaymentPopup(false);
    }
  };

  if (loading) return <p className="text-center mt-10">Loading car details...</p>;
  if (error) return <p className="text-center mt-10 text-red-500">{error}</p>;

  return (
    <div>
      <Navbar />
      <div className="container mx-auto px-6 py-12">
        <h1 className="text-3xl font-bold mb-6 text-center">Car Booking</h1>
        {car && (
          <div className="bg-white shadow-lg rounded-lg p-6 flex flex-col md:flex-row">
            <img src={car.imageUrl} alt={car.name} className="w-full md:w-1/2 rounded-lg" />
            <div className="md:ml-6 flex flex-col justify-between w-full md:w-1/2">
              <div>
                <h2 className="text-2xl font-bold mb-4">{car.companyName}</h2>
                <p className="text-gray-700 mb-2">Model: {car.modelName}</p>
                {car.location && (
                  <p className="text-gray-700 mb-2">📍 Pickup: {car.location}</p>
                )}
                <p className="text-gray-900 font-semibold text-xl">Price: ₹{car.dailyRentalCost}/day</p>
                <p className="text-gray-900 font-semibold text-xl">Price: ₹{car.hourlyRentalCost}/hr</p>

                {typeof car.latitude === "number" && typeof car.longitude === "number" && (
                  <div className="mt-4">
                    <p className="text-sm text-gray-600 mb-1">Pickup location</p>
                    <LocationMap lat={car.latitude} lng={car.longitude} height={200} />
                  </div>
                )}

                {/* Date-Time Inputs */}
                <label className="block text-gray-700 mt-4">Start Date & Time:</label>
                <input
                  type="datetime-local"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="border rounded px-2 py-1 w-full"
                />

                <label className="block text-gray-700 mt-2">End Date & Time:</label>
                <input
                  type="datetime-local"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="border rounded px-2 py-1 w-full"
                />
              </div>

              {/* Book Now Button */}
              <button
                className="mt-6 bg-blue-600 text-white py-2 px-6 rounded hover:bg-blue-700"
                onClick={handleBooking}
              >
                Book Now
              </button>
            </div>
          </div>
        )}
      </div>

      <Footer />

      {/* Dummy Payment Popup */}
      {showPaymentPopup && (
        <div className="fixed inset-0 bg-gray-900 bg-opacity-50 flex justify-center items-center">
          <div className="bg-white p-6 rounded shadow-lg text-center">
            <h2 className="text-xl font-bold mb-4">Enter Payment Details</h2>
            <input
              type="text"
              placeholder="Card Number"
              className="border px-3 py-2 rounded w-full mb-2"
            />
            <input
              type="text"
              placeholder="Expiry Date (MM/YY)"
              className="border px-3 py-2 rounded w-full mb-2"
            />
            <input
              type="text"
              placeholder="CVV"
              className="border px-3 py-2 rounded w-full mb-4"
            />
            <div className="flex gap-3 justify-center">
              <button
                className="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700"
                onClick={() => handlePayment("SUCCESS")}
              >
                Pay Now
              </button>
              <button
                className="bg-red-600 text-white px-6 py-2 rounded hover:bg-red-700"
                onClick={() => handlePayment("FAILED")}
              >
                Simulate Failure
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BookingPage;
