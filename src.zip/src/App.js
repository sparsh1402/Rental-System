import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import Home from "./pages/Home";
import SignUpPage from "./pages/SignUpPage";
import UserPanelPage from "./pages/UserPanelPage";
import { AuthProvider } from "./context/AuthContext";
import { ToastProvider } from "./context/ToastContext";
import ErrorBoundary from "./components/ErrorBoundary";
import "./styles/global.css";
import CarRentalPage from "./pages/CarRentalPage";
import BookingPage from "./pages/BookingPage";
import DocsPage from "./pages/DocsPage";
import ProtectedRoute from "./components/ProtectedRoute";
import AdminPage from "./pages/AdminPage";

const App = () => {
  return (
    <ErrorBoundary>
      <AuthProvider>
        <ToastProvider>
          <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/signup" element={<SignUpPage />} />
          <Route
            path="/user-panel"
            element={
              <ProtectedRoute>
                <UserPanelPage />
              </ProtectedRoute>
            }
          />
          <Route path="/car-rental" element={<CarRentalPage />} />
          <Route
            path="/car-rental/:carName"
            element={
              <ProtectedRoute>
                <BookingPage />
              </ProtectedRoute>
            }
          />
          <Route path="/docs" element={<DocsPage />} />
          <Route
            path="/admin"
            element={
              <ProtectedRoute role="ADMIN">
                <AdminPage />
              </ProtectedRoute>
            }
          />
          </Routes>
        </ToastProvider>
      </AuthProvider>
    </ErrorBoundary>
  );
};

export default App;
