import { createContext, useState, useEffect, useCallback } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { setUnauthorizedHandler } from "../api/client";

export const AuthContext = createContext();

const getTokenExpiryMs = (jwt) => {
  try {
    const payload = JSON.parse(atob(jwt.split(".")[1]));
    return payload.exp ? payload.exp * 1000 : null;
  } catch {
    return null;
  }
};

const isExpired = (jwt) => {
  const expMs = getTokenExpiryMs(jwt);
  return expMs !== null && Date.now() >= expMs;
};

const emptyAuth = { user: null, token: null, isLogged: false };

const readStoredAuth = () => {
  const storedUser = localStorage.getItem("user");
  const storedToken = localStorage.getItem("token");
  if (!storedUser || !storedToken || isExpired(storedToken)) {
    localStorage.removeItem("user");
    localStorage.removeItem("userId");
    localStorage.removeItem("token");
    return emptyAuth;
  }
  return {
    user: JSON.parse(storedUser),
    token: storedToken,
    isLogged: true,
  };
};

export const AuthProvider = ({ children }) => {
  // One object so logout is a SINGLE setState. React 17 does not batch
  // setState calls that come from setTimeout, so separate setUser(null)
  // then setIsLogged(false) would render once with user=null while still
  // "logged in" and crash Navbar/UserPanel.
  const [auth, setAuth] = useState(readStoredAuth);
  const navigate = useNavigate();
  const location = useLocation();

  const logout = useCallback(
    (reason) => {
      setAuth(emptyAuth);
      localStorage.removeItem("user");
      localStorage.removeItem("userId");
      localStorage.removeItem("token");
      if (reason === "expired") {
        sessionStorage.setItem("sessionExpired", "1");
      }
      if (location.pathname !== "/") {
        navigate("/", { replace: true });
      }
    },
    [navigate, location.pathname]
  );

  useEffect(() => {
    if (!auth.token) return;
    const expMs = getTokenExpiryMs(auth.token);
    if (expMs === null) return;
    const msLeft = expMs - Date.now();
    if (msLeft <= 0) {
      logout("expired");
      return;
    }
    const timer = setTimeout(() => logout("expired"), msLeft);
    return () => clearTimeout(timer);
  }, [auth.token, logout]);

  useEffect(() => {
    setUnauthorizedHandler(() => logout("expired"));
    return () => setUnauthorizedHandler(() => {});
  }, [logout]);

  const login = (userData, jwtToken) => {
    sessionStorage.removeItem("sessionExpired");
    setAuth({ user: userData, token: jwtToken, isLogged: true });
    localStorage.setItem("user", JSON.stringify(userData));
    localStorage.setItem("userId", userData.id);
    localStorage.setItem("token", jwtToken);
  };

  return (
    <AuthContext.Provider
      value={{
        isLogged: auth.isLogged,
        user: auth.user,
        token: auth.token,
        login,
        logout,
        setIsLogged: (value) =>
          setAuth((prev) => ({ ...prev, isLogged: Boolean(value) })),
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};
