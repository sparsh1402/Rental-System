# Rental Microservices Learning Platform

An event-driven rebuild of the Car Rental monolith into Spring Cloud Gateway + 5
services + Kafka, designed to teach **microservices, Kafka, multithreading, and
free-tier AWS deployment**.

## Architecture

```
React SPA ──▶ api-gateway (JWT validation at the edge)
                 ├─▶ auth-user-service      (authdb)
                 ├─▶ vehicle-service        (vehicledb)        ◀─ consumes reservation events
                 ├─▶ reservation-service    (reservationdb)    ◀─ consumes payment events
                 └─▶ payment-service        (paymentdb)        ◀─ consumes reservation events
                          │
                          ▼
                   Kafka (KRaft)  ──▶ notification-service (pure consumer)
```

- **Gateway** validates the JWT and injects `X-Auth-User-*` headers downstream.
- **Booking saga (choreography):** `reservation.created` → payment initialized →
  user confirms → `payment.completed`/`payment.failed` → reservation confirmed or
  compensated (cancelled), which frees the vehicle.
- **Topics:** `reservation-events`, `payment-events` (+ auto `*.DLT` dead-letter
  topics). Messages are keyed by `vehicleId` for per-vehicle ordering.

## Ports

| Service               | Port |
|-----------------------|------|
| api-gateway           | 8080 |
| auth-user-service     | 8081 |
| vehicle-service       | 8082 |
| reservation-service   | 8083 |
| payment-service       | 8084 |
| kafka-ui              | 8085 |
| notification-service  | 8086 |
| frontend (dev CRA)    | 3000 |
| Postgres              | 5432 |
| Kafka (host listener) | 9094 |

## Run it

### Option A — everything in Docker

```bash
cd rental-microservices
cp .env.example .env          # set JWT_SECRET etc.
docker compose up --build
# open http://localhost:3000
```

### Option B — infra in Docker, services from your IDE

```bash
cd rental-microservices
docker compose -f docker-compose.infra.yml up -d   # Postgres + Kafka + Kafka UI
mvn clean install                                  # build all modules
# then run each *Application main class (or `mvn spring-boot:run` per module)
cd ../car-rental-frontend && npm install && npm start
```

## Concepts demonstrated

- **Multithreading:** per-vehicle pessimistic lock prevents double-booking
  (`ConcurrentBookingTest` fires 16 simultaneous bookings; exactly one wins),
  `CompletableFuture` parallel aggregation of user+vehicle, `@Async` audit side
  effect, `@Scheduled` reservation-expiry job, tunable consumer concurrency.
- **Kafka:** producers/consumers, consumer groups, partitioning by `vehicleId`,
  class-level `@KafkaHandler` type routing, retries + dead-letter topics,
  idempotent consumers.
- **Deployment:** lean JVM heaps, single Postgres with a DB per service, Kafka in
  KRaft mode (no ZooKeeper), nginx serving the SPA and proxying the gateway.

## Deploy to AWS free tier

See `deploy/ec2-setup.sh`. In short: launch a t3.micro (Amazon Linux 2023),
open ports 22 and 80, run the setup script (installs Docker + 4 GB swap), then:

```bash
JWT_SECRET=... CORS_ALLOWED_ORIGIN=http://<public-ip> \
  docker compose -f docker-compose.prod.yml up -d --build
```

> 1 GB RAM is tight for 6 JVMs + Kafka + Postgres. The lean heaps + swap make it
> boot, but **t3.small (2 GB)** is the comfortable choice. The frontend can also
> be hosted free on S3 + CloudFront instead of the EC2.
