package com.carrental.vehicle.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties(prefix = "vehicle.storage")
public class StorageProperties {

    /** Directory on disk where uploaded vehicle images are written. */
    private String uploadDir = "uploads/vehicle-images";

    /** Public base URL prefix used to build the returned image URL. */
    private String publicBaseUrl = "http://localhost:8080";

    public String getUploadDir() {
        return uploadDir;
    }

    public void setUploadDir(String uploadDir) {
        this.uploadDir = uploadDir;
    }

    public String getPublicBaseUrl() {
        return publicBaseUrl;
    }

    public void setPublicBaseUrl(String publicBaseUrl) {
        this.publicBaseUrl = publicBaseUrl;
    }
}
