import { useEffect, useState,useContext } from "react";
import { AuthContext } from "../context/AuthContext";
import { API_BASE_URL } from "../config";
const Dashboard = () => {
    const [user, setUser] = useState(null);
    const [reservations, setReservations] = useState([]);
    const [error, setError] = useState(null);
  
    const userId = localStorage.getItem("userId");
    const { token } = useContext(AuthContext);

    const fetchReservations = async () => {
      if (!userId) return;
      try {
        const response = await fetch(`${API_BASE_URL}/api/reservations/user/${userId}`,{
          headers: {
            "Content-Type": "application/json",
            "Authorization": `Bearer ${token}`,
          },
        });
        if (!response.ok) {
          throw new Error(`HTTP error! Status: ${response.status}`);
        }
        const data = await response.json();
        setReservations(data);
      } catch (err) {
        setError("Failed to load reservations. Please try again later.");
      }
    };

    useEffect(() => {
      fetchReservations();
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [userId]);

    const handleCancel = async (id) => {
      if (!window.confirm("Cancel this booking?")) return;
      try {
        const res = await fetch(`${API_BASE_URL}/api/reservations/${id}/cancel`, {
          method: "DELETE",
          headers: { "Authorization": `Bearer ${token}` },
        });
        if (!res.ok && res.status !== 204) throw new Error("Cancel failed");
        fetchReservations();
      } catch (err) {
        setError("Failed to cancel booking.");
      }
    };

    const completedCount = reservations.filter((r) => r.status === "COMPLETED").length;
    const cancelledCount = reservations.filter((r) => r.status === "CANCELLED").length;

    const statusClass = (status) =>
      status === "COMPLETED"
        ? "bg-green-500"
        : status === "CANCELLED"
        ? "bg-red-500"
        : "bg-yellow-500";

    const paymentClass = (status) =>
      status === "PAID"
        ? "bg-green-500"
        : status === "FAILED"
        ? "bg-red-500"
        : "bg-gray-400";
  
    return (
        <div className="flex flex-col items-center">
        <div className="bg-white shadow-lg p-6 rounded-lg">
          <h2 className="text-3xl font-bold text-center mb-6">My Dashboard</h2>
          <div className="grid grid-cols-3 gap-6">
            <div className="bg-blue-500 text-white shadow-md p-6 rounded-lg text-center">
              <h3 className="text-2xl font-bold">{reservations.length}</h3>
              <p>Total Orders</p>
            </div>
            <div className="bg-green-500 text-white shadow-md p-6 rounded-lg text-center">
              <h3 className="text-2xl font-bold">{completedCount}</h3>
              <p>Completed</p>
            </div>
            <div className="bg-red-500 text-white shadow-md p-6 rounded-lg text-center">
              <h3 className="text-2xl font-bold">{cancelledCount}</h3>
              <p>Cancelled</p>
            </div>
          </div>
  
          <div className="bg-white shadow-md p-6 rounded-lg mt-6">
            <h3 className="text-xl font-bold mb-4">My Recent Orders</h3>
            {error ? (
              <p className="text-red-500">{error}</p>
            ) : (
              <table className="w-full border-collapse">
                <thead>
                  <tr className="bg-gray-200">
                    <th className="border p-2">Booking No</th>
                    <th className="border p-2">Vehicle</th>
                    <th className="border p-2">Pickup</th>
                    <th className="border p-2">Date</th>
                    <th className="border p-2">Return Date</th>
                    <th className="border p-2">Amount</th>
                    <th className="border p-2">Payment</th>
                    <th className="border p-2">Status</th>
                    <th className="border p-2">Action</th>
                  </tr>
                </thead>
                <tbody>
                  {reservations.length > 0 ? (
                    reservations.map((res, index) => (
                      <tr key={index} className="border-b">
                        <td className="border p-2">#{res.id}</td>
                        <td className="border p-2">{res.vehicle?.companyName} {res.vehicle?.modelName}</td>
                        <td className="border p-2">{res.vehicle?.location || "—"}</td>
                        <td className="border p-2">{res.startDate}</td>
                        <td className="border p-2">{res.endDate}</td>
                        <td className="border p-2">₹{res.totalCost}</td>
                        <td className="border p-2">
                          <span className={`px-2 py-1 rounded text-white ${paymentClass(res.paymentStatus)}`}>
                            {res.paymentStatus}
                          </span>
                        </td>
                        <td className="border p-2">
                          <span className={`px-2 py-1 rounded text-white ${statusClass(res.status)}`}>
                            {res.status}
                          </span>
                        </td>
                        <td className="border p-2">
                          {res.status === "SCHEDULED" || res.status === "INPROGRESS" ? (
                            <button
                              onClick={() => handleCancel(res.id)}
                              className="text-red-600 hover:underline"
                            >
                              Cancel
                            </button>
                          ) : (
                            <span className="text-gray-400">—</span>
                          )}
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan="9" className="border p-2 text-center text-gray-500">
                        No reservations found.
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            )}
          </div>
        </div>
      </div>
    );
  };
  

export default Dashboard;
