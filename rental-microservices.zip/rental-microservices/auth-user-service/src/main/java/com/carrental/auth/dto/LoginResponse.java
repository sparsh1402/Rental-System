package com.carrental.auth.dto;

public record LoginResponse(String token, UserResponse user) {
}
