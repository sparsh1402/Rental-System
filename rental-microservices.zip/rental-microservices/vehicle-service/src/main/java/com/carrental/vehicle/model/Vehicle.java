package com.carrental.vehicle.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Table(name = "vehicles")
@Getter
@Setter
@NoArgsConstructor
public class Vehicle {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String vehicleNumber;
    private String companyName;
    private String modelName;

    @Enumerated(EnumType.STRING)
    private VehicleType vehicleType;

    @Enumerated(EnumType.STRING)
    private VehicleStatus status = VehicleStatus.AVAILABLE;

    private double dailyRentalCost;
    private double hourlyRentalCost;
    private String imageUrl;

    /** Human-readable pickup location (e.g. city / branch). */
    private String location;

    /** Optional geo coordinates for the pickup point (map display/picker). */
    private Double latitude;
    private Double longitude;

    /** Optimistic-lock version: guards concurrent status updates from saga events. */
    @Version
    private Long version;
}
