package com.carrental.payment.messaging;

import com.carrental.common.events.KafkaTopics;
import com.carrental.common.events.PaymentCompletedEvent;
import com.carrental.common.events.PaymentFailedEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

@Component
public class PaymentEventPublisher {

    private static final Logger log = LoggerFactory.getLogger(PaymentEventPublisher.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;

    public PaymentEventPublisher(KafkaTemplate<String, Object> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void publishCompleted(PaymentCompletedEvent event) {
        log.info("Publishing PaymentCompleted for reservation {}", event.reservationId());
        kafkaTemplate.send(KafkaTopics.PAYMENT_EVENTS, String.valueOf(event.vehicleId()), event);
    }

    public void publishFailed(PaymentFailedEvent event) {
        log.info("Publishing PaymentFailed for reservation {}", event.reservationId());
        kafkaTemplate.send(KafkaTopics.PAYMENT_EVENTS, String.valueOf(event.vehicleId()), event);
    }
}
