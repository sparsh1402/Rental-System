package com.carrental.common.events;

/**
 * Centralized Kafka topic names so producers and consumers never drift apart.
 * Dead-letter topics are suffixed with ".DLT" and created/used by the consumers.
 */
public final class KafkaTopics {

    private KafkaTopics() {
    }

    public static final String RESERVATION_EVENTS = "reservation-events";
    public static final String PAYMENT_EVENTS = "payment-events";
    public static final String NOTIFICATION_EVENTS = "notification-events";

    public static final String RESERVATION_EVENTS_DLT = "reservation-events.DLT";
    public static final String PAYMENT_EVENTS_DLT = "payment-events.DLT";
}
