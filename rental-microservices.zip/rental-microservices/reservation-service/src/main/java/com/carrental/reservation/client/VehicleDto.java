package com.carrental.reservation.client;

/** Subset of the vehicle representation that reservation-service needs. */
public record VehicleDto(
        Long id,
        String companyName,
        String modelName,
        String imageUrl,
        String status,
        double dailyRentalCost,
        double hourlyRentalCost,
        String location
) {
}
