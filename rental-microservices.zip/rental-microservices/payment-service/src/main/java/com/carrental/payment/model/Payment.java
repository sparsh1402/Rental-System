package com.carrental.payment.model;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

@Entity
@Table(name = "payments", uniqueConstraints = @UniqueConstraint(columnNames = "reservationId"))
@Getter
@Setter
@NoArgsConstructor
public class Payment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Unique per reservation: enforces idempotent payment creation. */
    @Column(nullable = false, unique = true)
    private Long reservationId;

    private Long vehicleId;
    private double amount;

    @Enumerated(EnumType.STRING)
    private PaymentRecordStatus status = PaymentRecordStatus.PENDING;

    private Instant createdAt = Instant.now();
    private Instant updatedAt;
}
