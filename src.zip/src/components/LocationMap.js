import { MapContainer, TileLayer, Marker, useMapEvents } from "react-leaflet";
import L from "leaflet";
import "leaflet/dist/leaflet.css";

// Leaflet's default marker icons break under webpack; point them at the CDN.
const markerIcon = new L.Icon({
  iconUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png",
  iconRetinaUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png",
  shadowUrl: "https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png",
  iconSize: [25, 41],
  iconAnchor: [12, 41],
  popupAnchor: [1, -34],
  shadowSize: [41, 41],
});

// India centroid as a sensible default when no coordinates are set yet.
const DEFAULT_CENTER = [20.5937, 78.9629];

const ClickHandler = ({ onChange }) => {
  useMapEvents({
    click(e) {
      if (onChange) onChange(e.latlng.lat, e.latlng.lng);
    },
  });
  return null;
};

/**
 * Reusable Leaflet map.
 * - Display mode: pass lat/lng.
 * - Picker mode: also pass onChange(lat, lng); clicking the map sets the marker.
 */
const LocationMap = ({ lat, lng, onChange, height = 260, zoom = 11 }) => {
  const hasPoint = typeof lat === "number" && typeof lng === "number";
  const center = hasPoint ? [lat, lng] : DEFAULT_CENTER;

  return (
    <MapContainer
      center={center}
      zoom={hasPoint ? zoom : 4}
      style={{ height: `${height}px`, width: "100%", borderRadius: "0.5rem" }}
      scrollWheelZoom={false}
    >
      <TileLayer
        attribution='&copy; OpenStreetMap contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {hasPoint && <Marker position={[lat, lng]} icon={markerIcon} />}
      {onChange && <ClickHandler onChange={onChange} />}
    </MapContainer>
  );
};

export default LocationMap;
