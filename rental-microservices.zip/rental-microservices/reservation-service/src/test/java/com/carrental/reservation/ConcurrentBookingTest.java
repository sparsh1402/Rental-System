package com.carrental.reservation;

import com.carrental.reservation.client.UserClient;
import com.carrental.reservation.client.UserDto;
import com.carrental.reservation.client.VehicleClient;
import com.carrental.reservation.client.VehicleDto;
import com.carrental.reservation.messaging.ReservationEventPublisher;
import com.carrental.reservation.repository.ReservationRepository;
import com.carrental.reservation.service.ReservationService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.Mockito.when;

/**
 * Proves the double-booking guard: when N threads try to book the SAME vehicle
 * for the SAME overlapping window simultaneously, exactly one succeeds. The
 * per-vehicle pessimistic lock plus the overlap check serialize the attempts.
 */
@SpringBootTest
class ConcurrentBookingTest {

    @Autowired
    private ReservationService reservationService;

    @Autowired
    private ReservationRepository reservationRepository;

    @MockBean
    private VehicleClient vehicleClient;

    @MockBean
    private UserClient userClient;

    @MockBean
    private ReservationEventPublisher publisher; // no real Kafka in the test

    @Test
    void onlyOneBookingWinsForTheSameVehicleAndWindow() throws Exception {
        long vehicleId = 100L;
        when(userClient.getUser(anyLong())).thenReturn(new UserDto(1L, "Alice", "a@x.com", "USER"));
        when(vehicleClient.getVehicle(anyLong()))
                .thenReturn(new VehicleDto(vehicleId, "Tesla", "Model 3", null, "AVAILABLE", 2400, 100, "Pune"));

        int threads = 16;
        ExecutorService pool = Executors.newFixedThreadPool(threads);
        CountDownLatch start = new CountDownLatch(1);
        AtomicInteger success = new AtomicInteger();
        AtomicInteger rejected = new AtomicInteger();
        CountDownLatch done = new CountDownLatch(threads);

        for (int i = 0; i < threads; i++) {
            final long userId = i + 1;
            pool.submit(() -> {
                try {
                    start.await();
                    reservationService.createReservation(
                            userId, vehicleId, "2030-01-01T10:00", "2030-01-03T10:00");
                    success.incrementAndGet();
                } catch (Exception e) {
                    rejected.incrementAndGet();
                } finally {
                    done.countDown();
                }
            });
        }

        start.countDown();
        done.await(30, TimeUnit.SECONDS);
        pool.shutdownNow();

        assertThat(success.get()).isEqualTo(1);
        assertThat(rejected.get()).isEqualTo(threads - 1);
        assertThat(reservationRepository.findAll()).hasSize(1);
    }
}
