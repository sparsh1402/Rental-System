package com.carrental.reservation.repository;

import com.carrental.reservation.model.VehicleLock;
import jakarta.persistence.LockModeType;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface VehicleLockRepository extends JpaRepository<VehicleLock, Long> {

    /**
     * Acquires a row-level write lock (SELECT ... FOR UPDATE) on the vehicle's
     * lock row. Concurrent transactions block here until the holder commits,
     * which serializes booking attempts per vehicle.
     */
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @Query("select v from VehicleLock v where v.id = :id")
    Optional<VehicleLock> findByIdForUpdate(@Param("id") Long id);
}
