package com.carrental.vehicle.messaging;

import com.carrental.common.events.KafkaTopics;
import com.carrental.common.events.ReservationCancelledEvent;
import com.carrental.common.events.ReservationCreatedEvent;
import com.carrental.vehicle.model.VehicleStatus;
import com.carrental.vehicle.service.VehicleService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaHandler;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * Vehicle-service reacts to the booking saga: a vehicle becomes RENTED when a
 * reservation is created and AVAILABLE again when it is cancelled (which also
 * covers the payment-failure compensation, since reservation-service emits a
 * cancellation in that case).
 *
 * Class-level @KafkaListener + @KafkaHandler dispatches by event type using the
 * JSON type header written by the producer.
 */
@Component
@KafkaListener(topics = KafkaTopics.RESERVATION_EVENTS, groupId = "vehicle-service")
public class VehicleEventConsumer {

    private static final Logger log = LoggerFactory.getLogger(VehicleEventConsumer.class);

    private final VehicleService vehicleService;

    public VehicleEventConsumer(VehicleService vehicleService) {
        this.vehicleService = vehicleService;
    }

    @KafkaHandler
    public void onCreated(ReservationCreatedEvent event) {
        log.info("Reservation {} created -> renting vehicle {}", event.reservationId(), event.vehicleId());
        vehicleService.changeStatus(event.vehicleId(), VehicleStatus.RENTED);
    }

    @KafkaHandler
    public void onCancelled(ReservationCancelledEvent event) {
        log.info("Reservation {} cancelled -> releasing vehicle {}", event.reservationId(), event.vehicleId());
        vehicleService.changeStatus(event.vehicleId(), VehicleStatus.AVAILABLE);
    }

    @KafkaHandler(isDefault = true)
    public void onOther(Object event) {
        log.debug("Ignoring reservation event type {}", event.getClass().getSimpleName());
    }
}
