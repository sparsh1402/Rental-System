package com.carrental.payment.controller;

import com.carrental.payment.service.PaymentService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    private final PaymentService paymentService;

    public PaymentController(PaymentService paymentService) {
        this.paymentService = paymentService;
    }

    @PostMapping("/confirm")
    public ResponseEntity<Map<String, String>> confirm(@RequestParam Long reservationId,
                                                       @RequestParam String status) {
        String message = paymentService.confirm(reservationId, status);
        return ResponseEntity.ok(Map.of("message", message));
    }
}
