package com.carrental.reservation.client;

import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClient;

import java.util.NoSuchElementException;

@Component
public class VehicleClient {

    private final RestClient restClient;

    public VehicleClient(ClientProperties properties) {
        this.restClient = RestClient.create(properties.getVehicleUrl());
    }

    public VehicleDto getVehicle(Long id) {
        VehicleDto vehicle = restClient.get()
                .uri("/api/vehicles/{id}", id)
                .retrieve()
                .body(VehicleDto.class);
        if (vehicle == null) {
            throw new NoSuchElementException("Vehicle not found: " + id);
        }
        return vehicle;
    }
}
