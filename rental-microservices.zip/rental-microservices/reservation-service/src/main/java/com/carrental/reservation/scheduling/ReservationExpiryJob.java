package com.carrental.reservation.scheduling;

import com.carrental.reservation.service.ReservationService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Periodically expires stale (unpaid, past end date) reservations. Spring runs
 * @Scheduled methods on a dedicated scheduler thread pool, so this work never
 * blocks request threads.
 */
@Component
public class ReservationExpiryJob {

    private final ReservationService reservationService;

    public ReservationExpiryJob(ReservationService reservationService) {
        this.reservationService = reservationService;
    }

    @Scheduled(fixedDelayString = "${reservation.expiry.fixed-delay-ms:300000}")
    public void expire() {
        reservationService.expireStaleReservations();
    }
}
