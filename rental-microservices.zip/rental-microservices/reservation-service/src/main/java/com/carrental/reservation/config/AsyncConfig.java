package com.carrental.reservation.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Thread pools used by this service.
 *
 * Sizing rationale: the aggregation work is I/O-bound (REST calls to other
 * services), so a small fixed pool with a bounded queue is enough; we keep it
 * lean to stay within the free-tier memory budget.
 */
@Configuration
public class AsyncConfig {

    /** Used by CompletableFuture aggregation (parallel calls to vehicle + user). */
    @Bean(name = "aggregationExecutor")
    public Executor aggregationExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(4);
        executor.setMaxPoolSize(8);
        executor.setQueueCapacity(50);
        executor.setThreadNamePrefix("agg-");
        executor.initialize();
        return executor;
    }

    /** Default @Async executor for fire-and-forget side effects. */
    @Bean(name = "taskExecutor")
    public Executor taskExecutor() {
        ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
        executor.setCorePoolSize(2);
        executor.setMaxPoolSize(4);
        executor.setQueueCapacity(100);
        executor.setThreadNamePrefix("async-");
        executor.initialize();
        return executor;
    }
}
