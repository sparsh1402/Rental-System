#!/usr/bin/env bash
#
# One-time setup for an Amazon Linux 2023 / Ubuntu EC2 host to run the rental
# microservices stack via Docker Compose. Run as a sudo-capable user.
#
#   chmod +x ec2-setup.sh && ./ec2-setup.sh
#
# After this completes, log out/in (for the docker group) then:
#   cd rental-microservices
#   JWT_SECRET=... CORS_ALLOWED_ORIGIN=http://<public-ip> \
#     docker compose -f docker-compose.prod.yml up -d --build
#
# Security group: open inbound TCP 22 (SSH) and 80 (HTTP) only.
# Strongly recommended: attach an Elastic IP so the address is stable.

set -euo pipefail

echo "==> Detecting package manager"
if command -v dnf >/dev/null 2>&1; then
  PKG="sudo dnf -y"
elif command -v yum >/dev/null 2>&1; then
  PKG="sudo yum -y"
elif command -v apt-get >/dev/null 2>&1; then
  PKG="sudo apt-get -y"
  sudo apt-get update
else
  echo "Unsupported package manager" >&2
  exit 1
fi

echo "==> Installing Docker"
if ! command -v docker >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then
    $PKG install ca-certificates curl gnupg
    curl -fsSL https://get.docker.com | sudo sh
  else
    $PKG install docker
  fi
fi

echo "==> Enabling and starting Docker"
sudo systemctl enable --now docker

echo "==> Adding current user to the docker group"
sudo usermod -aG docker "$USER" || true

echo "==> Installing Docker Compose plugin (if missing)"
if ! docker compose version >/dev/null 2>&1; then
  DOCKER_CONFIG=${DOCKER_CONFIG:-$HOME/.docker}
  mkdir -p "$DOCKER_CONFIG/cli-plugins"
  curl -SL "https://github.com/docker/compose/releases/latest/download/docker-compose-linux-$(uname -m)" \
    -o "$DOCKER_CONFIG/cli-plugins/docker-compose"
  chmod +x "$DOCKER_CONFIG/cli-plugins/docker-compose"
fi

echo "==> Creating a 4 GB swap file (helps a 1 GB t3.micro avoid OOM)"
if [ ! -f /swapfile ]; then
  sudo fallocate -l 4G /swapfile || sudo dd if=/dev/zero of=/swapfile bs=1M count=4096
  sudo chmod 600 /swapfile
  sudo mkswap /swapfile
  sudo swapon /swapfile
  echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
fi

echo "==> Done. Log out and back in so the docker group applies, then deploy."
free -h
