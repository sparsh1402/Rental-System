import React, { useContext, useEffect, useState } from "react";
import Navbar from "../components/Navbar";
import HeroSection from "../components/HeroSection";
import SearchBar from "../components/SearchBar";
import VehicleSharingSection from "../components/VehicleSharingSection";
import RentalOptions from "../components/RentalOptions";
import WhyChooseUs from "../components/WhyChooseUs";
import Testimonials from "../components/Testimonials";
import LocalService from "../components/LocalService";
import FAQ from "../components/FAQ";
import Footer from "../components/Footer";
import SignUp from "../components/SignUp";
import SignIn from "../components/SignIn";
import { AuthContext } from "../context/AuthContext";
import { useNavigate } from "react-router-dom";
const Home = () => {
  const [showSignUp, setShowSignUp] = useState(false);
  const [showSignIn, setShowSignIn] = useState(false);
  const { logout } = useContext(AuthContext);
  const [sessionNotice, setSessionNotice] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    if (sessionStorage.getItem("sessionExpired") === "1") {
      sessionStorage.removeItem("sessionExpired");
      setSessionNotice("Your session expired. Please sign in again.");
    }
  }, []);

  const handleRegisterSuccess = () => {
    setShowSignUp(false);
    setShowSignIn(false);
    setSessionNotice("");
  };

  const handleLogout = () => {
    setShowSignIn(false);
    logout();
    navigate("/");
  };

  return (
    <div>
      <Navbar onSignUpClick={() => setShowSignUp(true)} onSignInClick={() => setShowSignIn(true)} onLogout={handleLogout} />
      {sessionNotice && (
        <div className="mx-auto mt-4 max-w-xl rounded bg-amber-100 px-4 py-3 text-center text-amber-800">
          {sessionNotice}
        </div>
      )}
      
      {showSignUp && (
        <SignUp 
          onClose={() => setShowSignUp(false)} 
          onRegisterSuccess={handleRegisterSuccess}
          onSwitchToSignIn={() => { setShowSignUp(false); setShowSignIn(true); }}  
        />
      )}
      {showSignIn && <SignIn onClose={() => setShowSignIn(false)} onLoginSuccess={handleRegisterSuccess}  onSwitchToSignUp={() => { setShowSignIn(false); setShowSignUp(true); }} />}

      <HeroSection />
      <div className="flex justify-center mt-10">
        <SearchBar />
      </div>
      <RentalOptions />
      <VehicleSharingSection />
      <WhyChooseUs />
      <Testimonials />
      <LocalService />
      <FAQ />
      <Footer />
    </div>
  );
};

export default Home;
