package com.carrental.gateway.security;

import com.carrental.common.events.GatewayHeaders;
import io.jsonwebtoken.Claims;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.http.HttpStatus;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import reactor.core.publisher.Mono;

import java.util.List;

/**
 * Edge authentication. Validates the JWT once at the gateway and forwards the
 * authenticated identity to downstream services as trusted headers. Downstream
 * services therefore never re-parse the token.
 */
@Component
public class JwtAuthenticationFilter implements GlobalFilter, Ordered {

    private static final Logger log = LoggerFactory.getLogger(JwtAuthenticationFilter.class);

    /** Paths that never require a token. */
    private static final List<String> OPEN_PATHS = List.of(
            "/api/users/login",
            "/api/users/register",
            "/uploads",
            "/actuator/health"
    );

    private final JwtValidator jwtValidator;

    public JwtAuthenticationFilter(JwtValidator jwtValidator) {
        this.jwtValidator = jwtValidator;
    }

    @Override
    public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
        ServerHttpRequest request = exchange.getRequest();
        String path = request.getURI().getPath();

        if (isOpen(path) || isPublicVehicleBrowse(exchange)) {
            return chain.filter(exchange);
        }

        String authHeader = request.getHeaders().getFirst("Authorization");
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return unauthorized(exchange, "Missing or malformed Authorization header");
        }

        String token = authHeader.substring(7);
        try {
            Claims claims = jwtValidator.parse(token);
            String role = String.valueOf(claims.get("role"));

            if (requiresAdmin(exchange) && !"ADMIN".equals(role)) {
                return forbidden(exchange, "Admin role required");
            }

            ServerHttpRequest mutated = request.mutate()
                    .header(GatewayHeaders.USER_EMAIL, claims.getSubject())
                    .header(GatewayHeaders.USER_ID, String.valueOf(claims.get("userId")))
                    .header(GatewayHeaders.USER_ROLE, role)
                    .build();
            return chain.filter(exchange.mutate().request(mutated).build());
        } catch (Exception e) {
            log.warn("Rejected request to {}: {}", path, e.getMessage());
            return unauthorized(exchange, "Invalid or expired token");
        }
    }

    /** Mutating the vehicle catalog (create/update/delete/image) is ADMIN-only. */
    private boolean requiresAdmin(ServerWebExchange exchange) {
        String path = exchange.getRequest().getURI().getPath();
        org.springframework.http.HttpMethod method = exchange.getRequest().getMethod();
        return path.startsWith("/api/vehicles")
                && (method == org.springframework.http.HttpMethod.POST
                    || method == org.springframework.http.HttpMethod.PUT
                    || method == org.springframework.http.HttpMethod.DELETE);
    }

    private boolean isOpen(String path) {
        return OPEN_PATHS.stream().anyMatch(path::startsWith);
    }

    /** Browsing the vehicle catalog (GET /api/vehicles/**) is public. */
    private boolean isPublicVehicleBrowse(ServerWebExchange exchange) {
        String path = exchange.getRequest().getURI().getPath();
        return path.startsWith("/api/vehicles")
                && exchange.getRequest().getMethod() == org.springframework.http.HttpMethod.GET;
    }

    private Mono<Void> unauthorized(ServerWebExchange exchange, String reason) {
        exchange.getResponse().setStatusCode(HttpStatus.UNAUTHORIZED);
        exchange.getResponse().getHeaders().add("X-Auth-Error", reason);
        return exchange.getResponse().setComplete();
    }

    private Mono<Void> forbidden(ServerWebExchange exchange, String reason) {
        exchange.getResponse().setStatusCode(HttpStatus.FORBIDDEN);
        exchange.getResponse().getHeaders().add("X-Auth-Error", reason);
        return exchange.getResponse().setComplete();
    }

    @Override
    public int getOrder() {
        // Run before the routing filter so headers are injected on the proxied request.
        return -1;
    }
}
