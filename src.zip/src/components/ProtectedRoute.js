import { useContext } from "react";
import { Navigate } from "react-router-dom";
import { AuthContext } from "../context/AuthContext";

/**
 * Wraps a page that must not be opened unless the user is signed in
 * (and optionally has a specific role). If the check fails, send them home
 * instead of rendering a half-broken page.
 */
const ProtectedRoute = ({ children, role }) => {
  const { isLogged, user } = useContext(AuthContext);

  if (!isLogged || !user) {
    return <Navigate to="/" replace />;
  }

  if (role && user.role !== role) {
    return <Navigate to="/" replace />;
  }

  return children;
};

export default ProtectedRoute;
