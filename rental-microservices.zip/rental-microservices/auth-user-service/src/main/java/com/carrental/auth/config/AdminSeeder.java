package com.carrental.auth.config;

import com.carrental.auth.model.User;
import com.carrental.auth.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.crypto.password.PasswordEncoder;

/**
 * Seeds a single ADMIN account on startup (if absent) so the admin console is
 * usable out of the box. Credentials are configurable via admin.seed.* and
 * should be overridden in any real environment.
 */
@Configuration
public class AdminSeeder {

    private static final Logger log = LoggerFactory.getLogger(AdminSeeder.class);

    @Bean
    public ApplicationRunner seedAdmin(UserRepository userRepository,
                                       PasswordEncoder passwordEncoder,
                                       AdminSeederProperties props) {
        return args -> {
            if (!props.isEnabled() || userRepository.existsByEmail(props.getEmail())) {
                return;
            }
            User admin = new User();
            admin.setName(props.getName());
            admin.setEmail(props.getEmail());
            admin.setPassword(passwordEncoder.encode(props.getPassword()));
            admin.setRole("ADMIN");
            userRepository.save(admin);
            log.info("Seeded ADMIN user '{}'", props.getEmail());
        };
    }
}
