package com.carrental.vehicle.model;

public enum VehicleType {
    CAR, BIKE
}
