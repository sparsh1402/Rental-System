import { API_BASE_URL } from "../config";

let onUnauthorized = () => {};

/** AuthContext registers logout here so a 401 can end the session in one place. */
export const setUnauthorizedHandler = (handler) => {
  onUnauthorized = handler || (() => {});
};

/**
 * One HTTP helper for the whole SPA.
 * - prefixes API_BASE_URL
 * - attaches Bearer token from localStorage (unless skipAuth)
 * - on 401 for authenticated calls: session expired → logout callback
 * - does not set Content-Type for FormData (browser must set the boundary)
 */
export async function apiFetch(path, { skipAuth = false, headers, ...options } = {}) {
  const token = localStorage.getItem("token");
  const nextHeaders = { ...(headers || {}) };

  if (!(options.body instanceof FormData) && !nextHeaders["Content-Type"]) {
    if (options.body && typeof options.body === "string") {
      nextHeaders["Content-Type"] = "application/json";
    }
  }

  if (!skipAuth && token) {
    nextHeaders.Authorization = `Bearer ${token}`;
  }

  const response = await fetch(`${API_BASE_URL}${path}`, {
    ...options,
    headers: nextHeaders,
  });

  if (!skipAuth && response.status === 401) {
    onUnauthorized();
    throw new Error("Session expired. Please sign in again.");
  }

  return response;
}

/** Like apiFetch, but parses JSON and throws with a readable message on failure. */
export async function apiJson(path, options) {
  const response = await apiFetch(path, options);
  if (response.status === 204) {
    return null;
  }
  const text = await response.text();
  const data = text ? JSON.parse(text) : null;
  if (!response.ok) {
    const message =
      (data && (data.message || data.error)) || `Request failed (${response.status})`;
    throw new Error(message);
  }
  return data;
}
